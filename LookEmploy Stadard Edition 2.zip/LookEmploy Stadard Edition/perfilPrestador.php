<?php
    // Iniciar a sessão
    session_start();

    // Verificar se o usuário está logado
    if (!isset($_SESSION['usuario'])) {
        // Redirecionar para a página de login se não estiver logado
        header('location: login.html');
        exit();
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Perfil</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap">
    <link rel="stylesheet" href="css/design_perfilPrestador.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link rel="icon" type="image/png" href="img/logo_icon.png">
</head>
<body>
   <div class="toda_pagina">
    <header>
        <a href="index.html"><h1><img class="header-img" src="img/logo.png"></h1></a>
        <nav>
           
          
        </nav>
    </header>
      <main>
          <h1> Área do prestador</h1>
       
    </main>
     <div class="op_butao">
        <button>Agendados</button>
     </div>
    <section class="info-area">
        <div class="fot"> 
            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTD6XP__oH0pmB9z0GuQjtIT2P6cCXzAp1C9Q&s">
        </div>
        <div class="info">
                <h2>Inserir nome</h2>
                <p> localização:</p>
                <p>Serviço solicitado:</p>
                <p> <strong>Ver mais</strong></p>
        </div>

    </section>

       
    </div>

   
</body>
</html>