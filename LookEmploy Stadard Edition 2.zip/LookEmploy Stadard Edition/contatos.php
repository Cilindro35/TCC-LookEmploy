<?php
    // Iniciar a sessão
    session_start();

    // Verificar se o usuário está logado
    if (!isset($_SESSION['usuario'])) {
        // Redirecionar para a página de login se não estiver logado
        header('location: login.html');
        exit();
    }
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Perfil</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap">
    <link rel="stylesheet" href="css/design_contatos.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link rel="icon" type="image/png" href="img/logo_icon.png">
</head>
<body>
    <!--RODAPÉ-->
    <header>
        <nav>
            <a href="index.html"><img src="img/logo.png" style="width: 140px; height: 40px;" alt="LookEmploy"></a>
            <div>
                <!--sininho-->
                <a href="">
                    <img src="img/icone_notificacoes.png" alt="Notificações">
                </a>

                <!--mais-->
                <a href="">
                    <img src="img/icone_mais.png" alt="Mais">
                </a>
            </nav>
        </div>
    </header>

    <!--MENU LATERAL-->
    <section class="menuLateral">
        <!--Inicio-->
        <a class="menuItem" href="telaInicialCliente.php" target="_self">
            <img src="img/icone_inicio.png" alt="Inicio">
            <label>Inicio</label>
        </a>

        <!--Pedidos-->
        <a class="menuItem" href="pedidos.php" target="_self">
            <img src="img/icone_pedidos.png" alt="Pedidos">
            <label>Pedidos</label>
        </a>

        <!--Contatos-->
        <a class="menuItem" href="contatos.php" target="_self">
            <img src="img/icone_contatos.png" alt="Contatos">
            <label>Contatos</label>
        </a>

        <!--Perfil-->
        <a class="menuItem" href="perfilCliente.php" target="_self">
            <img src="img/icone_perfil.png" alt="Perfil">
            <label>Perfil</label>
        </a>
    </section>

    <!--CONTATOS-->
    <section class="contatos">
        <!--botoes de filtro-->
        <h1>Contatos</h1>
        <section class="filtros">
            <button class="">Todos</button>
            <button class="">Bloqueados</button>
        </section>

        <!--lista de contatos-->
        <section class="listaContatos"> 
            <div class='item'>
                <img class='perfilImg' src='img/icone_perfil.png' alt='Usuario'>
                <div class='descricao'>
                    <h2>Henrique</h2>
                    <p>Você: Olá, quando está disponível para a visita?</p>
                    <p>11/09/2001 - 03:30</p>
                </div>
            </div>
        </section>
    </section>
</body>
</html>
