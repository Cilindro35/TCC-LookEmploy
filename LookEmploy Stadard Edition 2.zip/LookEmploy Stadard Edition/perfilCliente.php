<?php
    // Iniciar a sessão
    session_start();

    // Verificar se o usuário está logado
    if (!isset($_SESSION['usuario'])) {
        // Redirecionar para a página de login se não estiver logado
        header('location: login.html');
        exit();
    }
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Perfil</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap">
    <link rel="stylesheet" href="css/design_perfilCliente.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link rel="icon" type="image/png" href="img/logo_icon.png">
</head>
<body>
    <!--RODAPÉ-->
    <header>
        <nav>
            <a href="index.html"><img src="img/logo.png" style="width: 140px; height: 40px;" alt="LookEmploy"></a>
            <div>
                <!--sininho-->
                <a href="">
                    <img src="img/icone_notificacoes.png" alt="Notificações">
                </a>

                <!--mais-->
                <a href="">
                    <img src="img/icone_mais.png" alt="Mais">
                </a>
            </nav>
        </div>
    </header>

    <!--MENU LATERAL-->
    <section class="menuLateral">
        <!--Inicio-->
        <a class="menuItem" href="telaInicialCliente.php" target="_self">
            <img src="img/icone_inicio.png" alt="Inicio">
            <label>Inicio</label>
        </a>

        <!--Pedidos-->
        <a class="menuItem" href="pedidos.php" target="_self">
            <img src="img/icone_pedidos.png" alt="Pedidos">
            <label>Pedidos</label>
        </a>

        <!--Contatos-->
        <a class="menuItem" href="contatos.php" target="_self">
            <img src="img/icone_contatos.png" alt="Contatos">
            <label>Contatos</label>
        </a>

        <!--Perfil-->
        <a class="menuItem" href="perfilCliente.php" target="_self">
            <img src="img/icone_perfil.png" alt="Perfil">
            <label>Perfil</label>
        </a>
    </section>

    <!--PERFIL-->    
    <section class="perfil">
        <!--FOTO E OPÇÕES-->
        <section class="secao" style="background: linear-gradient(to top, white 45%, whitesmoke 45%);">
            <div class="informacoes">
                <!--FOTO E NOME-->
                <div class="row">
                    <img class="fotoPerfil" src="img/icone_perfil.png" alt="Foto de perfil">
                    <?php echo "<h1>". htmlspecialchars($_SESSION["nome"])."</h1>"; ?>
                </div>

                <!--BOTÕES-->
                <div class="row">
                    <button>Avaliações</button>
                    <a href="editarPerfilCliente.php"><button>Editar perfil</button></a>
                    <a href="php/realizarLogout.php"><button>Sair da conta</button></a>
                </div>
            </div>
        </section>

        <hr style="margin: 16px 10% 16px 10%">
        
        <!--DESCRIÇÃO E NECESSIDADE-->
        <section class="secao">
            <div class="descricao">
                <h1>Descrição</h1>
                <?php
                    if($_SESSION["descricao"] != null) {
                        echo "<p>". htmlspecialchars($_SESSION["descricao"])."</p>"; 
                    }
                ?>
            </div>
        </section>

        <!--ENDEREÇO-->
        <section class="secao">
            <h1>Endereço</h1>
            <div class="endereco">
                <div class="item"></item><p>Bairro</p>
                <?php echo "<p>". htmlspecialchars($_SESSION["bairro"])."</p>"; ?></div>
                <div class="item"><p>Logradouro</p>
                <?php echo "<p>". htmlspecialchars($_SESSION["logradouro"])."</p>"; ?></div>
                <div class="item"><p>Numero</p>
                <?php echo "<p>". htmlspecialchars($_SESSION["numero"])."</p>"; ?></div>
                <div class="item"><p>Complemento</p>
                <?php
                    if($_SESSION["complemento"] != "")echo "<p>". htmlspecialchars($_SESSION["complemento"])."</p>"; 
                ?>
                </div>
            </div>
        </section>

        <!--DADOS DA CONTA-->
        <section class="secao">
            <h1>Dados</h1>
            <div class="dados">
                <div class="item"><p>ID</p>
                <?php echo "<p>". htmlspecialchars($_SESSION["usuario"])."</p>"; ?></div>
                <div class="item"><p>E-mail</p>
                <?php echo "<p>". htmlspecialchars($_SESSION["email"])."</p>"; ?></div>
                <div class="item"><p>Telefone</p>
                <?php echo "<p>". htmlspecialchars($_SESSION["telefone"])."</p>"; ?></div>
            </div>
        </section>
    </section>
</body>
</html>
