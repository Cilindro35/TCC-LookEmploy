<?php
  session_start();
  include_once 'conexaoMySQL.php';

  // Tipo de usuário (ex: Cliente, Prestador)
  $tipo = 'cliente';

  // Campos do formulário
  $email = $_POST['email'] ?? '';
  $nome = $_POST['nome'] ?? '';
  $telefone = $_POST['telefone'] ?? '';
  $data_nascimento = $_POST['dataNascimento'] ?? '';
  $bairro = $_POST['bairro'] ?? '';
  $logradouro = $_POST['logradouro'] ?? '';
  $numero = $_POST['numero'] ?? '';
  $complemento = $_POST['complemento'] ?? '';
  $sexo = $_POST['sexo'] ?? '';
  $descricao = $_POST['desc'] ??'';

  // ID do usuário logado
  $idUsuario = $_SESSION['usuario'] ?? null;

  // Validação básica
  if (!$idUsuario || !$tipo) {
      echo "Erro: usuário ou tipo não informado.";
      exit;
  }

  // Monta o SQL dinamicamente conforme os campos
  $sql = "UPDATE $tipo SET nome = ?, email = ?, telefone = ?, dataNascimento = ?, bairro = ?, logradouro = ?, numero = ?, complemento = ?, sexo = ?, descricao = ?";
  $sql .= " WHERE ID = ?";

  $stmt = $conexao->prepare($sql);

  if (!$stmt) {
      echo "Erro ao preparar o SQL: " . $conexao->error;
      exit;
  }

  // Associa os parâmetros
  $stmt->bind_param("ssssssssssi",$nome,$email,$telefone,$data_nascimento,$bairro,$logradouro,$numero,$complemento,$sexo,$descricao,$idUsuario);

  // Executa o comando
  if ($stmt->execute()) {
      echo "Dados atualizados com sucesso!";
      // Atualiza os dados da sessão
      $_SESSION['nome'] = $nome;
      //$_SESSION['email'] = $email;
      //$_SESSION['telefone'] = $telefone;
      $_SESSION['descricao'] = $descricao;
      $_SESSION['complemento'] = $complemento;
  } else {
      echo "Erro ao atualizar: " . $stmt->error;
  }

  $stmt->close();
  $conexao->close();
?>
