<?php
    // Iniciar a sessão
    session_start();

    // Verificar se o usuário está logado
    if (!isset($_SESSION['usuario'])) {
        // Redirecionar para a página de login se não estiver logado
        header('location: login.html');
        exit();
    }
    else {
        //conexão com o banco de dados
        $conn = new mysqli('localhost', 'root', '', 'lookemploy');
        if ($conn->connect_error) {
            die("Erro de conexão: " . $conn->connect_error);
        }
        else {
            //filtro
            $categoria = $_GET['categoria'] ?? 'todos';
            if ($categoria != 'todos') {
                $stmt = $conn->prepare("SELECT ID, nome, sobrenome, descricao, avaliacao, caminhoImagemPerfil FROM prestador WHERE tipoServico = ?");
                $stmt->bind_param("s", $categoria);
                $stmt->execute();
                $result = $stmt->get_result();
            } else {
                $result = $conn->query("SELECT ID, nome, sobrenome, descricao, avaliacao, caminhoImagemPerfil FROM prestador");
            }
        }
    }
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TelaInicial</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link rel="stylesheet" href="css/design_telaInicial.css">
    <link rel="icon" type="image/png" href="img/logo_icon.png">
</head>
<body>
    <!--Menu lateral-->
    <div id="inserirMenuLateral"></div>

    <!--BARRA DE PESQUISA-->
    <section class="telaInicial">
        <!--Categorias-->
        <h1>Categorias</h1>
        <a href="?categoria=todos"><button>Todos</button></a>

        <!--Banners-->
        <section class="banners">
            <a href="?categoria=pedreiro" class="card">
                <img src="https://tse2.mm.bing.net/th/id/OIP.Dg4-k3_iKwL9cuf6PcyFsAHaE8?cb=12&rs=1&pid=ImgDetMain&o=7&rm=3" alt="Pedreiro">
                <p>Pedreiro</p>
            </a>

            <a href="?categoria=encanador" class="card">
                <img src="https://tacontratado.com.br/meunegocio/wp-content/uploads/2024/04/encanador-6.png" alt="Encanador">
                <p>Encanador</p>
            </a>

            <a href="?categoria=eletricista" class="card">
                <img src="https://engehall.com.br/wp-content/uploads/2023/08/curso-de-eletricista-instalador.webp" alt="Eletricista">
                <p>Eletricista</p>
            </a>

            <a href="?categoria=marceneiro" class="card">
                <img src="https://tse4.mm.bing.net/th/id/OIP.jLRgRimCb6hguM1V7N-5JQHaE7?cb=12&rs=1&pid=ImgDetMain&o=7&rm=3" alt="Marceneiro">
                <p>Marceneiro</p>
            </a>
        </section>

        <!--Recomendados-->
        <h1>Serviços recomendados</h1>
        <section class="recomendados">
            <?php
if ($result->num_rows > 0) {
    while($item = $result->fetch_assoc()) {

        $imgPerfil = !empty($item['caminhoImagemPerfil']) 
                     ? "img/img_perfil/" . rawurlencode($item['caminhoImagemPerfil']) 
                     : "img/img_perfil/default.png";

        echo "<a href='visualizarPrestador.php?id={$item['ID']}'>
                <div class='item'>
                    <img class='perfilImg' src='{$imgPerfil}' alt='Usuario'>

                    <div class='descricao'>
                        <div style='display: flex; align-items: center; gap: 8px;'>
                            <h2>" . 
                                htmlspecialchars($item['nome']) . " " . 
                                htmlspecialchars($item['sobrenome']) . 
                            "</h2>";
                                
                        for ($i = 0; $i < $item['avaliacao']; $i++) {
                            echo "<i class='fa-solid fa-star' style='color: #5CE1E6;'></i>";
                        }

        echo           "</div>
                        <p style='
                            display: -webkit-box;
                            -webkit-line-clamp: 2;
                            -webkit-box-orient: vertical;
                            overflow: hidden;
                        '>" . htmlspecialchars($item['descricao']) . "</p>
                    </div>
                </div>
            </a>";
    }
} else {
    echo "<p>Nenhum item encontrado.</p>";
}

$conn->close();
?>

        </section>
    </section>
    <script src="js/menuLateral.js"></script>
</body>
</html>
