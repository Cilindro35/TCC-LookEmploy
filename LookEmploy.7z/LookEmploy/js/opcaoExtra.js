const select = document.getElementById('tipo');
const campoExtra = document.getElementById('campoExtra');
const btex = document.getElementById("excluirConta")
const mo = document.getElementById("modalex")
const dc = document.getElementById("contex")
let btcancel = document.getElementById("cancelarExclusao")
//const campoExtra2 = document.getElementById('campoExtra2');

select.addEventListener('change', function () {
  if (select.value === 'Prestador') {
    campoExtra.style.display = 'block';
    //campoExtra2.style.display = 'block';
  } else {
    campoExtra.style.display = 'none';
    //campoExtra2.style.display = 'none';
  }
});

  btex.addEventListener( 'click', async () => {
    const resposta = await fetch('confirmarExclusaoConta');
    const html = await resposta.text();
    dc.innerHTML = html;
    mo.classList.add('on');
    btcancel = document.getElementById("cancelarExclusao");
    if (btcancel) {
      btcancel.addEventListener("click", (e) =>{
        e.preventDefault();
        dc.innerHTML = "";
        mo.classList.remove('on');

        


      });
    }
    mo.addEventListener("click", (e) => {
      if (e.target === mo) {
        dc.innerHTML = "";
        mo.classList.remove('on');
      }
  });

  });