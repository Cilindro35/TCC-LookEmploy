fetch("menuLateral.html")
        .then(res => res.text())
        .then(html => {
            document.getElementById("inserirMenuLateral").innerHTML = html;
        });