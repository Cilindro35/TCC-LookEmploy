document.getElementById("formServico").addEventListener("submit", function(e) {
    e.preventDefault();

    document.getElementById("formServico").addEventListener("submit", function(e) {
        e.preventDefault(); // impede envio até validar

        let valido = true;
        let mensagemFinal = document.getElementById("mensagemFinal");

        // limpar mensagens anteriores
        document.querySelectorAll(".erro").forEach(span => span.textContent = "");

        // validar cada campo
        if(this.bairro.value.trim() === ""){
            this.bairro.nextElementSibling.textContent = "Informe o bairro.";
            valido = false;
        }
        if(this.logradouro.value.trim() === ""){
            this.logradouro.nextElementSibling.textContent = "Informe o logradouro.";
            valido = false;
        }
        if(this.numero.value.trim() === "" || isNaN(this.numero.value)){
            this.numero.nextElementSibling.textContent = "Informe um número válido.";
            valido = false;
        }
        if(this.data.value === ""){
            this.data.nextElementSibling.textContent = "Informe a data.";
            valido = false;
        }
        if(this.horario.value === ""){
            this.horario.nextElementSibling.textContent = "Informe o horário.";
            valido = false;
        }
        if(this.desc.value.trim().length < 10){
            this.desc.nextElementSibling.textContent = "Descrição deve ter pelo menos 10 caracteres.";
            valido = false;
        }
        if(this.pagamento.value === ""){
            this.pagamento.nextElementSibling.textContent = "Selecione um método de pagamento.";
            valido = false;
        }

        if(valido){
            let formData = new FormData(this);

            fetch("contratarServico.php?id=1", {
                method: "POST",
                body: formData
            })
            .then(response => response.text())
            .then(data => {
                mensagemFinal.style.color = "green";
                mensagemFinal.textContent = data; // mostra resposta do PHP
            })
            .catch(error => {
                mensagemFinal.style.color = "red";
                mensagemFinal.textContent = "Erro ao contratar serviço: " + error;
            });
        } else {
            mensagemFinal.style.color = "red";
            mensagemFinal.textContent = "Corrija os erros acima antes de continuar.";
        }
    });
});
