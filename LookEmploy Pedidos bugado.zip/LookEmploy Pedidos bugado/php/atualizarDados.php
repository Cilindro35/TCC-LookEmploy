<?php
session_start();
include_once 'conexaoMySQL.php';

// Tipo de usuário (ex: Cliente, Prestador)
$tipo = $_SESSION['tipo'] ?? "";

// Validar tipo permitido
$tiposPermitidos = ['Cliente', 'Prestador'];
if (!in_array($tipo, $tiposPermitidos)) {
    echo "Tipo inválido.";
    exit;
}

// Campos do formulário
$nome = $_POST['nome'] ?? '';
$data_nascimento = $_POST['dataNascimento'] ?? '';
$bairro = $_POST['bairro'] ?? '';
$logradouro = $_POST['logradouro'] ?? '';
$numero = $_POST['numero'] ?? '';
$complemento = $_POST['complemento'] ?? '';
$sexo = $_POST['sexo'] ?? '';
$descricao = $_POST['desc'] ?? '';
$servico = $_POST['servico'] ?? '';

$idUsuario = (int) ($_SESSION['usuario'] ?? 0);

// Validação básica
if ($idUsuario <= 0 || $tipo == "" || $nome == "" || $data_nascimento == "" || $bairro == "" || $logradouro == "" || $numero == "" || $sexo == "") {
    echo "Dados incompletos.";
    exit;
}

// -------------------------------------------
// PROCESSAR IMAGEM
// -------------------------------------------

$caminhoImagem = null;

// Verifica se o usuário enviou nova imagem
if (isset($_FILES['imagemPerfil']) && $_FILES['imagemPerfil']['error'] === 0) {

    $pasta = "imagensPerfil";
    $nomeTemp = $_FILES['imagemPerfil']['tmp_name'];
    $nomeFinal = time() . "_" . basename($_FILES['imagemPerfil']['name']);

    // Criar pasta se necessário
    if (!is_dir($pasta)) {
        mkdir($pasta, 0777, true);
    }

    // Mover o arquivo (corrigido com "/")
    if (move_uploaded_file($nomeTemp, $pasta . "/" . $nomeFinal)) {
        $caminhoImagem = $pasta . "/" . $nomeFinal;
    }
}

// Se não enviou imagem nova, manter a antiga
if (!$caminhoImagem) {
    $result = $conexao->query("SELECT caminhoImagemPerfil FROM $tipo WHERE ID = $idUsuario");
    if ($result && $row = $result->fetch_assoc()) {
        $caminhoImagem = $row['caminhoImagemPerfil'];
    }
}

// MONTAR SQL
if ($servico != "") {
    $sql = "UPDATE $tipo SET nome = ?, dataNascimento = ?, bairro = ?, logradouro = ?, numero = ?, complemento = ?, sexo = ?, descricao = ?, tipoServico = ?, caminhoImagemPerfil = ? WHERE ID = ?";
    $stmt = $conexao->prepare($sql);
    if (!$stmt) {
        echo "Erro ao preparar o SQL: " . $conexao->error;
        exit;
    }
    $stmt->bind_param(
        "ssssssssssi",
        $nome,
        $data_nascimento,
        $bairro,
        $logradouro,
        $numero,
        $complemento,
        $sexo,
        $descricao,
        $servico,
        $caminhoImagem,
        $idUsuario
    );
} else {
    $sql = "UPDATE $tipo SET nome = ?, dataNascimento = ?, bairro = ?, logradouro = ?, numero = ?, complemento = ?, sexo = ?, descricao = ?, caminhoImagemPerfil = ? WHERE ID = ?";
    $stmt = $conexao->prepare($sql);
    if (!$stmt) {
        echo "Erro ao preparar o SQL: " . $conexao->error;
        exit;
    }
    $stmt->bind_param(
        "sssssssssi",
        $nome,
        $data_nascimento,
        $bairro,
        $logradouro,
        $numero,
        $complemento,
        $sexo,
        $descricao,
        $caminhoImagem,
        $idUsuario
    );
}

// EXECUTANDO O COMANDO
if ($stmt->execute()) {

    // Atualizar sessão
    $_SESSION['nome'] = $nome;
    $_SESSION['descricao'] = $descricao;
    $_SESSION['bairro'] = $bairro;
    $_SESSION['dataNascimento'] = $data_nascimento;
    $_SESSION['logradouro'] = $logradouro;
    $_SESSION['numero'] = $numero;
    $_SESSION['tipoServico'] = $servico;
    $_SESSION['complemento'] = $complemento;
    $_SESSION['sexo'] = $sexo;
    $_SESSION['caminhoImagemPerfil'] = $caminhoImagem;

    header("Location: ../perfil.php");
    exit; // importante para garantir que não haja saída depois
} else {
    echo "Erro ao atualizar: " . $stmt->error;
}

$stmt->close();
$conexao->close();
?>
