<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>alterarSenha</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap">
    <link rel="stylesheet" href="css/design_alterarSenha.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link rel="icon" type="image/png" href="img/logo_icon.png">
    <link href="https://fonts.googleapis.com/css2?family=Anton&display=swap" rel="stylesheet">
</head>
<body>
    <!--RODAPÉ-->
    <header>
        <nav>
            <a href="index.html"><img src="img/logo.png" style="width: 140px; height: 40px;" alt="LookEmploy"></a>
            <div>
                <!--sininho-->
                <a href="">
                    <img src="img/icone_notificacoes.png" alt="Notificações">
                </a>

                <!--mais-->
                <a href="">
                    <img src="img/icone_mais.png" alt="Mais">
                </a>
            </nav>
        </div>
    </header>

    <!--MENU LATERAL-->
    <section class="menuLateral">
        <!--Inicio-->
        <a class="menuItem" href="telaInicial.php" target="_self">
            <img src="img/icone_inicio.png" alt="Inicio">
            <label>Inicio</label>
        </a>

        <!--Pedidos-->
        <a class="menuItem" href="pedidos.php" target="_self">
            <img src="img/icone_pedidos.png" alt="Pedidos">
            <label>Pedidos</label>
        </a>

        <!--Contatos-->
        <a class="menuItem" href="contatos.php" target="_self">
            <img src="img/icone_contatos.png" alt="Contatos">
            <label>Contatos</label>
        </a>

        <!--Perfil-->
        <a class="menuItem" href="perfil.php" target="_self">
            <img src="img/icone_perfil.png" alt="Perfil">
            <label>Perfil</label>
        </a>
    </section>

    <!--ALTERAR SENHA-->
    <section class="alterarSenha">
        <form class="formulario" id="formulario" action="php/realizarLogin.php" method="post">
            <h2>Alterar Senha</h2>
            <div class="row"><a target="_self" href="editarPerfil.php"><input type="button" value="Voltar" ></a></div>

            <!-- Senha atual-->
            <input type="password" id="senha" name="senha" placeholder="Senha">
            <span id="senhaInvalida"></span>

            <!-- Nova senha -->
            <input type="password" id="novaSenha" name="novaSenha" placeholder="Nova Senha">
            <span id="novaSenhaInvalida"></span>

            <input type="submit" value="Alterar">
            <p id="msgSucesso"></p>
        </form>
    </section>
</div>
<!--<script src="js/validacaoLogin.js"></script>-->
   
</body>
</html>