<?php
  session_start();
  include_once 'conexaoMySQL.php';

  // Tipo de usuário (ex: Cliente, Prestador)
  $tipo = $_SESSION['tipo'] ?? "";

  // Campos do formulário
  $nome = $_POST['nome'] ?? '';
  $data_nascimento = $_POST['dataNascimento'] ?? '';
  $bairro = $_POST['bairro'] ?? '';
  $logradouro = $_POST['logradouro'] ?? '';
  $numero = $_POST['numero'] ?? '';
  $complemento = $_POST['complemento'] ?? '';
  $sexo = $_POST['sexo'] ?? '';
  $descricao = $_POST['desc'] ??'';
  $servico = $_POST['servico'] ?? '';

  // ID do usuário logado
  $idUsuario = $_SESSION['usuario'] ?? null;

  // Validação básica
  if ($idUsuario == "" || $tipo == "" || $nome == "" || $data_nascimento == "" || $bairro == "" || $logradouro == "" || $numero == "" || $sexo == "") {
      echo "Dados incompletos.";
      exit;
  }

  // Monta o SQL dinamicamente conforme os campos
  if($servico != "")$sql = "UPDATE $tipo SET nome = ?, dataNascimento = ?, bairro = ?, logradouro = ?, numero = ?, complemento = ?, sexo = ?, descricao = ?, tipoServico = ?";
  else $sql = "UPDATE $tipo SET nome = ?, dataNascimento = ?, bairro = ?, logradouro = ?, numero = ?, complemento = ?, sexo = ?, descricao = ?";
  $sql .= " WHERE ID = ?";

  $stmt = $conexao->prepare($sql);

  if (!$stmt) {
      echo "Erro ao preparar o SQL: " . $conexao->error;
      exit;
  }

  // Associa os parâmetros
  if($servico != "")$stmt->bind_param("sssssssssi",$nome,$data_nascimento,$bairro,$logradouro,$numero,$complemento,$sexo,$descricao,$servico,$idUsuario);
  else $stmt->bind_param("ssssssssi",$nome,$data_nascimento,$bairro,$logradouro,$numero,$complemento,$sexo,$descricao,$idUsuario);

  // Executa o comando
  if ($stmt->execute()) {
      echo "Dados atualizados com sucesso!";
      // Atualiza os dados da sessão
      $_SESSION['nome'] = $nome;
      $_SESSION['descricao'] = $descricao;
      $_SESSION['bairro'] = $bairro;
      $_SESSION['logradouro'] = $logradouro;
      $_SESSION['numero'] = $numero;
      $_SESSION['tipoServico'] = $servico;
      $_SESSION['complemento'] = $complemento;
  } else {
      echo "Erro ao atualizar: " . $stmt->error;
  }

  $stmt->close();
  $conexao->close();
?>
