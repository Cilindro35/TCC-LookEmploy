<?php
    // Iniciar a sessão
    session_start();

    // Verificar se o usuário está logado
    if (!isset($_SESSION['usuario'])) {
        // Redirecionar para a página de login se não estiver logado
        header('location: login.html');
        exit();
    }
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contatos</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap">
    <link rel="stylesheet" href="css/design_contatos.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link rel="icon" type="image/png" href="img/logo_icon.png">
</head>
<body>
    <!--Menu lateral-->
    <div id="inserirMenuLateral"></div>

    <!--CONTATOS-->
    <section class="contatos">
    
        <!--lista de contatos-->
        <aside class="contato">
          <h2>Contatos</h2>
          
            <ul class="lis_ch">
              <li class="cont_atual">
                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTD6XP__oH0pmB9z0GuQjtIT2P6cCXzAp1C9Q&s" class="foto_contato">
                <span> Davi Britto</span>
              </li>
              <li class="contat">
                <img src="https://tse2.mm.bing.net/th/id/OIP.uChdds8E4jEyqb9YN5Pq0AHaDt?rs=1&pid=ImgDetMain&o=7&rm=3" class="foto_contato">
                <span> Juliette Freire</span>
              </li>
              <li class="contat">
                <img src="https://tse4.mm.bing.net/th/id/OIP.6zzgHDiUow6iOfNOt6GwcAHaE-?rs=1&pid=ImgDetMain&o=7&rm=3" class="foto_contato">
                <span> Babu Santana</span>
              </li>
            </ul>
            
          </aside>
    </section>
    <script src="js/menuLateralContatos.js"></script>
    <script src="js/menuLateral.js"></script>
</body>
</html>
