const select = document.getElementById('tipo');
const campoExtra = document.getElementById('campoExtra');
//const campoExtra2 = document.getElementById('campoExtra2');

select.addEventListener('change', function () {
  if (select.value === 'Prestador') {
    campoExtra.style.display = 'block';
    //campoExtra2.style.display = 'block';
  } else {
    campoExtra.style.display = 'none';
    //campoExtra2.style.display = 'none';
  }
});

  document.getElementById('excluirConta').addEventListener('click', async () => {
    const container = document.getElementById('exibirExclusao');

    // Carrega overlay.html
    const resposta = await fetch('confirmarExclusaoConta.php');
    const html = await resposta.text();

    container.innerHTML = html;

    // Adiciona evento ao botão de fechar dentro do overlay
    document.getElementById('cancelarExclusao').addEventListener('click', () => {
        container.innerHTML = ''; // Remove a tela sobreposta
    });
});
