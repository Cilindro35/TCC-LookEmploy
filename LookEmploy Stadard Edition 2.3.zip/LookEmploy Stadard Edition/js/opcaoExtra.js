const select = document.getElementById('tipo');
const campoExtra = document.getElementById('campoExtra');
const campoExtra2 = document.getElementById('campoExtra2');

select.addEventListener('change', function () {
  if (select.value === 'Prestador') {
    campoExtra.style.display = 'block';
    campoExtra2.style.display = 'block';
  } else {
    campoExtra.style.display = 'none';
    campoExtra2.style.display = 'none';
  }
});
