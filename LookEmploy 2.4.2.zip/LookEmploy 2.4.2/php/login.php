<?php 
include_once 'conexaoMySQL.php';
 
  $tipo = $_POST['tipo'] ?? '';
  $email = $_POST['email'] ?? '';
  $senha = $_POST['senha'] ?? '';
?>