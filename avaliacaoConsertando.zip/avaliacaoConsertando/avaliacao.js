    var stars = document.querySelectorAll('.star');
    var estrelaInput = document.getElementById('estrelaSelecionada');
    var form = document.getElementById('formAvaliacao');
    var avaliacaoTextInput = document.getElementById('avaliacaoText');

    var estrelaErro = document.getElementById('estrelaErro');

    // Função para atualizar visualmente as estrelas
    function preencherEstrelas(valor) {
        stars.forEach(star => {
            const n = Number(star.dataset.value);
            star.src = n <= valor ? 'img/estrelaAvaliativa_preenchida.png' : 'img/estrelaAvaliativa_naoPreenchida.png';
        });
    }

    // Clique nas estrelas
    stars.forEach(star => {
        star.addEventListener('click', () => {
            const valor = Number(star.dataset.value);

            preencherEstrelas(valor);

            estrelaInput.value = valor; // salva só o número
        });
    });

    //VALIDACAO

    function validarEstrela(estrela) {
        if(!estrela && avaliacaoText) {
            estrelaErro.textContent = "Escolha um número de estrelas*";
            return false;
        }
        estrelaErro.textContent = "";
        return true;
    }

    form.addEventListener('submit', async (e) => {
        e.preventDefault();

        var estrela = estrelaInput.value;
        var avaliacaoText = avaliacaoTextInput.value;

        var estrelaValida = validarEstrela(estrela, avaliacaoText);
        console.log(avaliacaoText, estrela, estrelaValida);

        /*/ Exemplo de envio (AJAX via fetch)
        try {
            const resposta = await fetch("salvar.php", {
                method: "POST",
                headers: {"Content-Type": "application/json"},
                body: JSON.stringify(dados)
            });

            alert("Avaliação enviada com sucesso!");
        } catch (erro) {
            alert("Erro ao enviar avaliação.");
        }*/
    });