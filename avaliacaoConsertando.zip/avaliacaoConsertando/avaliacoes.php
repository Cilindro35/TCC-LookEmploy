<?php
    // Iniciar a sessão
    session_start();

    // Verificar se o usuário está logado
    if (!isset($_SESSION['usuario'])) {
        // Redirecionar para a página de login se não estiver logado
        header('location: login.html');
        exit();
    }
    else {
        //pegando o id da URL
        $id = $_GET['id'] ?? 1;

        if(is_numeric($id)) {
            //buscando os dados do prestador no banco de dados
            $conn = new mysqli('localhost', 'root', '', 'lookemploy');
            if ($conn->connect_error) {
                die("Erro de conexão: " . $conn->connect_error);
            }
            else {
                $stmt = $conn->prepare("SELECT nome, sobrenome, tipoServico, descricao, avaliacao, caminhoImagemPerfil FROM prestador WHERE ID = ?");
                $stmt->bind_param("s", $id);
                $stmt->execute();
                $result = $stmt->get_result();

                $row = $result->fetch_assoc();
                if ($row) {
                    $nome = $row["nome"];
                    $sobrenome = $row["sobrenome"];
                    $servico =  $row["tipoServico"];
                    $descricao = $row["descricao"];
                    $avaliacao = $row["avaliacao"];
                    $caminhoImagemPerfil = "img/img_perfil/" . $row["caminhoImagemPerfil"];
                }
            }
        }
        else exit();
    }
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>VisualizarPrestador</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap">
    <link rel="stylesheet" href="css/design_visualizarPrestador.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link rel="icon" type="image/png" href="img/logo_icon.png">
</head>
<style>
    .stars {
        display: flex;
        gap: 8px;
        cursor: pointer;
    }

    .star {
        width: 25px;
        height: auto;
        transition: 0.2s;
    }

    .star:hover {
        transform: scale(1.15);
    }

    #resultado {
        margin-top: 10px;
        font-size: 18px;
        font-weight: bold;
    }

    button {
        margin-top: 15px;
        padding: 8px 15px;
        font-size: 16px;
        cursor: pointer;
    }
</style>
<body>
    <!--Menu lateral-->
    <div id="inserirMenuLateral"></div>

    <!--PERFIL-->    
    <section class="perfil">
        <!--FOTO E OPÇÕES-->
        <section class="secao" style="background: linear-gradient(to top, white 45%, whitesmoke 45%);">

            <div class="informacoes">
                <!--FOTO E NOME-->
                <div class="inicio">
                    <img class="fotoPerfil" src="<?= $caminhoImagemPerfil ?>" alt="Foto de perfil">
                    <div class="column">
                        <!--NOME E DESCRIÇÃO-->
                        <?php echo "<h1>". htmlspecialchars($nome). " " . htmlspecialchars($sobrenome). "</h1>"; ?>

                        <!--avaliação-->
                        <div class="avaliacao">
                            <?php
                                for($i = 0; $i < $avaliacao; $i++) {
                                    echo "<i class='fa-solid fa-star' style='color: #5CE1E6;'></i>";
                                }
                            ?>
                        </div>
                    </div>
                </div>

                <!--BOTÕES-->
                <div class="row">
                    
                        <a href='VisualizarPrestador.php?id= <?= $id ?>'><button>Voltar</button></a>
                
                </div>
            </div>
        </section>
        <hr class="line">

        <div class="column">
            <form class="form">
                <h3>Deixe a sua avaliação:</h3>
                <!-- estrelas clicáveis -->
                <div class="stars">
                    <img class="star" data-value="1" src="img/estrelaAvaliativa_naoPreenchida.png">
                    <img class="star" data-value="2" src="img/estrelaAvaliativa_naoPreenchida.png">
                    <img class="star" data-value="3" src="img/estrelaAvaliativa_naoPreenchida.png">
                    <img class="star" data-value="4" src="img/estrelaAvaliativa_naoPreenchida.png">
                    <img class="star" data-value="5" src="img/estrelaAvaliativa_naoPreenchida.png">
                </div>
                
                <input type="hidden" id="estrelaSelecionada" name="estrela">
                <span id="estrelaErro" style="color: red;"></span>

                <textarea id="avaliacaoText" style="resize: none;" rows="7" placeholder="Escreva a sua opnião"></textarea>
                <button type="submit">Confirmar</button>
            </form>
        </div>
        <div class="column">
            
        </div>

    </section>
    <script src="js/avaliacao.js"></script>
    <script src="js/menuLateral.js"></script>
</body>
</html>