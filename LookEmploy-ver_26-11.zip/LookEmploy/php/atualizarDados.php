<?php
  session_start();
  include_once 'conexaoMySQL.php';

  // Tipo de usuário (ex: Cliente, Prestador)
  $tipo = $_SESSION['tipo'] ?? "";

  // Campos do formulário
  $nome = $_POST['nome'] ?? '';
  $sobrenome = $_POST['sobrenome'] ?? '';
  $telefone = $_POST['telefone'] ?? '';
  $bairro = $_POST['bairro'] ?? '';
  $logradouro = $_POST['logradouro'] ?? '';
  $numero = $_POST['numero'] ?? '';
  $complemento = $_POST['complemento'] ?? '';
  $descricao = $_POST['descricao'] ??'';
  if ($_SESSION['tipo'] == "Prestador") {
      $servico = $_POST['servico'] ?? ''; 
  }

  // ID do usuário logado
  $idUsuario = $_SESSION['usuario'] ?? null;

  // Validação básica
  if ($idUsuario == "" || $tipo == "" || $nome == ""  || $sobrenome == "" || $telefone == "" || $bairro == "" || $logradouro == "" || $numero == "" || $descricao == "") {
      echo "Dados incompletos.";
      exit;
  } else if($tipo == "Prestador" && $servico == "") {
    echo "Dados incompletos";
  }

  // Monta o SQL dinamicamente conforme os campos
  if($servico != "")$sql = "UPDATE $tipo SET nome = ?, bairro = ?, logradouro = ?, numero = ?, complemento = ?, descricao = ?, tipoServico = ?";
  else $sql = "UPDATE $tipo SET nome = ?, bairro = ?, logradouro = ?, numero = ?, complemento = ?, descricao = ?";
  $sql .= " WHERE ID = ?";

  $stmt = $conexao->prepare($sql);

  if (!$stmt) {
      echo "Erro ao preparar o SQL: " . $conexao->error;
      exit;
  }

  // Associa os parâmetros
  if($servico != "")$stmt->bind_param("sssssssi",$nome,$bairro,$logradouro,$numero,$complemento,$descricao,$servico,$idUsuario);
  else $stmt->bind_param("ssssssi",$nome,$bairro,$logradouro,$numero,$complemento,$descricao,$idUsuario);

  // Executa o comando
  if ($stmt->execute()) {
      echo "Dados atualizados com sucesso!";
      // Atualiza os dados da sessão
      $_SESSION['nome'] = $nome;
      $_SESSION['descricao'] = $descricao;
      $_SESSION['bairro'] = $bairro;
      $_SESSION['logradouro'] = $logradouro;
      $_SESSION['numero'] = $numero;
      if($servico != $servico) { $_SESSION['tipoServico'] = $servico; }
      $_SESSION['complemento'] = $complemento;
  } else {
      echo "Erro ao atualizar: " . $stmt->error;
  }

  $stmt->close();
  $conexao->close();
?>