<?php
try {
    $pdo = new PDO("mysql:host=localhost;dbname=chat;charset=utf8", "root", "");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (Exception $e) {
    die("Erro ao conectar: " . $e->getMessage());
}
?>
