<?php
    // Iniciar a sessão
    session_start();

    // Verificar se o usuário está logado
    if (!isset($_SESSION['usuario'])) {
        // Redirecionar para a página de login se não estiver logado
        header('location: login.html');
        exit();
    }
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pedidos</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap">
    <link rel="stylesheet" href="css/design_pedidos.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link rel="icon" type="image/png" href="img/logo_icon.png">
</head>
<body>
    <!--Menu lateral-->
    <div id="inserirMenuLateral"></div>

    <!--PEDIDOS-->
    <section class="pedidos">
        <!--botoes de filtro-->
        <h1>Pedidos</h1>
        <section class="filtros">
            <button class="">Todos</button>
            <button class="">Pendentes</button>
            <button class="">Em Andamento</button>
            <button class="">Concluídos</button>
        </section>

        <!--lista de pedidos-->
        <section class="listaPedidos"> 
            <div class='item'>
                <img class='perfilImg' src='img/icone_perfil.png' alt='Usuario'>
                <div class='descricao'>
                    <h2>Henrique</h2>
                    <p>Reforma no escritório. Adição de tomadas nas paredes.</p>
                    <p>Marcado para 16/09/2022 ao 12:00</p>
                </div>
            </div>
        </section>
    </section>
    <script src="js/menuLateral.js"></script>
</body>
</html>
