<?php
session_start();

if (!isset($_SESSION['usuario'])) {
    header('location: login.html');
    exit();
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contatos - Chat</title>

    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap">
    <link rel="stylesheet" href="css/design_contatos.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link rel="icon" type="image/png" href="img/logo_icon.png">
</head>
<body>

<div id="inserirMenuLateral"></div>

<section class="contatos-container">

    <!-- COLUNA ESQUERDA - CONTATOS -->
    <aside class="coluna-contatos">

        <div class="topo-contatos">
            <div class="campo-busca">
                <i class="fa fa-search"></i>
                <input type="text" id="buscarContato" placeholder="Buscar..." autocomplete="off">
            </div>
        </div>

        <ul id="listaUsuarios" class="lista-usuarios">
            <li class="usuario ativo" data-usuario="Davi Britto">
                <img src="img/user.png" alt="Davi Britto" class="foto-perfil">
                <div class="info">
                    <span class="nome">Davi Britto</span>
                    <span class="ultima-msg">Última mensagem</span>
                </div>
                <span class="hora-nome">00:00</span>
                <div class="dot-online"></div>
            </li>

            <li class="usuario" data-usuario="Juliette Freire">
                <img src="img/user.png" alt="Juliette Freire" class="foto-perfil">
                <div class="info">
                    <span class="nome">Juliette Freire</span>
                    <span class="ultima-msg">Última mensagem</span>
                </div>
                <span class="hora-nome">00:00</span>
                <div class="dot-offline"></div>
            </li>
        </ul>

    </aside>

    <!-- COLUNA DIREITA - CHAT -->
    <div class="coluna-chat">
        <div class="topo-chat">
            <div id="nomeContatoAtual" class="nome-topo">Selecione um contato</div>
            <div id="digitandoArea" class="digitando"></div>
        </div>

        <div id="chatMensagens" class="chat-mensagens">
            <!-- Mensagens serão carregadas aqui -->
        </div>

        <div class="input-chat">
            <input type="text" id="mensagem" placeholder="Digite a mensagem..." autocomplete="off">
            <button id="btnEnviar" class="btn-enviar" title="Enviar mensagem">
                <i class="fa-solid fa-paper-plane"></i>
            </button>
        </div>
    </div>

</section>

<script>
const CURRENT_USER = "<?php echo addslashes($_SESSION['usuario']); ?>";
</script>

<script src="js/menuLateral.js"></script>
<script src="js/contatos.js"></script>

</body>
</html>