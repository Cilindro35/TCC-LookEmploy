CREATE DATABASE LookEmploy;
USE LookEmploy;

CREATE TABLE Cliente (
	
	ID INT AUTO_INCREMENT PRIMARY KEY,
	
	nome VARCHAR(400) NOT NULL,
	sobrenome VARCHAR(400) NOT NULL,
	email VARCHAR(400) NOT NULL UNIQUE,
	senha VARCHAR(400) NOT NULL,
	telefone VARCHAR(11),
	bairro VARCHAR(200) NOT NULL,
	logradouro VARCHAR(200) NOT NULL,
	numero VARCHAR(10) NOT NULL,
	complemento VARCHAR(150),
	sexo VARCHAR(9) NOT NULL,
	-- genero VARCHAR(40) NOT NULL,
	dataNascimento DATE,

	descricao TEXT,
	caminhoImagemPerfil VARCHAR(255),
	caminhoImagemFundo VARCHAR(255)		
)ENGINE = InnoDB;

CREATE TABLE Prestador (

	ID INT AUTO_INCREMENT PRIMARY KEY,

	nome VARCHAR(400) NOT NULL,
	sobrenome VARCHAR(400) NOT NULL,
	email VARCHAR(400) NOT NULL UNIQUE,
	senha VARCHAR(400) NOT NULL,
	telefone VARCHAR(11),
	bairro VARCHAR(200) NOT NULL,
	logradouro VARCHAR(200) NOT NULL,
	numero VARCHAR(10) NOT NULL,
	complemento VARCHAR(150),
	sexo VARCHAR(9) NOT NULL,
	-- genero VARCHAR(40) NOT NULL,
	dataNascimento DATE,

	descricao TEXT,
	caminhoImagemPerfil VARCHAR(255),
	caminhoImagemFundo VARCHAR(255),

	tipoServico VARCHAR(11),
	avaliacao INT		
)ENGINE = InnoDB;

CREATE TABLE Servico (

	codigoServico INT PRIMARY KEY AUTO_INCREMENT,

	bairro VARCHAR(200) NOT NULL,
	logradouro VARCHAR(200) NOT NULL,
	numero VARCHAR(10) NOT NULL,
	complemento VARCHAR(150),
	dataServico DATETIME NOT NULL,
	tipoPagamento VARCHAR(150) NOT NULL,
	descricao TEXT,
	contrato TEXT,

	prestador INT NOT NULL,
	cliente INT NOT NULL,

	FOREIGN KEY (prestador) REFERENCES Prestador(ID),
	FOREIGN KEY (cliente) REFERENCES Cliente(ID) 
)ENGINE = InnoDB;

CREATE TABLE AnuncioServico (

	codigoAnuncio INT PRIMARY KEY AUTO_INCREMENT,

	bairro VARCHAR(200) NOT NULL,
	logradouro VARCHAR(200) NOT NULL,
	data DATETIME NOT NULL,
	descricao TEXT,
	tipoServico VARCHAR(11),
	cliente INT NOT NULL,

	FOREIGN KEY (cliente) REFERENCES Cliente(ID) 
)ENGINE = InnoDB;

CREATE TABLE usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(400) NOT NULL,
    email VARCHAR(400) NOT NULL UNIQUE,
    senha VARCHAR(400) NOT NULL,
    tipo ENUM('cliente','prestador') NOT NULL,
    online TINYINT(1) DEFAULT 0
);

CREATE TABLE mensagens (
    id INT AUTO_INCREMENT PRIMARY KEY,
    remetente_id INT NOT NULL,
    destinatario_id INT NOT NULL,
    mensagem TEXT NOT NULL,
    data_envio DATETIME DEFAULT CURRENT_TIMESTAMP,
    entregue TINYINT(1) DEFAULT 0,
    lido TINYINT(1) DEFAULT 0,

    FOREIGN KEY (remetente_id) REFERENCES usuarios(id),
    FOREIGN KEY (destinatario_id) REFERENCES usuarios(id)
);

ALTER TABLE mensagens 
MODIFY remetente_id INT,
MODIFY destinatario_id INT;

ALTER TABLE mensagens
ADD CONSTRAINT fk_remetente FOREIGN KEY (remetente_id) REFERENCES usuarios(id),
ADD CONSTRAINT fk_destinatario FOREIGN KEY (destinatario_id) REFERENCES usuarios(id);

ALTER TABLE Cliente
ADD usuario_id INT UNIQUE,
ADD FOREIGN KEY (usuario_id) REFERENCES usuarios(id);

ALTER TABLE Prestador
ADD usuario_id INT UNIQUE,
ADD FOREIGN KEY (usuario_id) REFERENCES usuarios(id);

SELECT DISTINCT u.id, u.nome, u.online
FROM usuarios u
JOIN mensagens m 
  ON (u.id = m.remetente_id OR u.id = m.destinatario_id)
WHERE u.id != :meu_id
  AND (:meu_id IN (m.remetente_id, m.destinatario_id));
