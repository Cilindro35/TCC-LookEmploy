<?php

namespace Api\WebSocket;

use Exception;
use Ratchet\MessageComponentInterface;
use Ratchet\ConnectionInterface;
use PDO;

class SistemaChat implements MessageComponentInterface 
{
    protected $clientes;
    protected $pdo;

    public function __construct()
    {
        $this->clientes = new \SplObjectStorage;

        try {
            $this->pdo = new PDO(
                "mysql:host=localhost;dbname=lookemploy;charset=utf8mb4", 
                "root", 
                "", 
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
                ]
            );
            echo "Conexão com banco 'chat' estabelecida com sucesso\n";
        } catch (Exception $e) {
            die("ERRO ao conectar ao banco: " . $e->getMessage() . "\n");
        }
    }

    public function onOpen(ConnectionInterface $conn)
    {
        // Associar usuário ao socket futuramente
        $conn->usuario = null;

        $this->clientes->attach($conn);
        echo "Conexão aberta: {$conn->resourceId}\n";
    }

    public function onMessage(ConnectionInterface $from, $msg)
    {
        $data = json_decode($msg, true);

        /* ============================================================
            1) REGISTRO DE LOGIN NO WEBSOCKET
        ============================================================ */
        if ($data["tipo"] === "login") {

            $from->usuario = $data["usuario"];

            // Marcar como online
            try {
                $this->pdo->prepare("UPDATE usuarios SET online = 1 WHERE nome = ?")
                    ->execute([$data["usuario"]]);
                echo "Usuário conectado no WS: {$data['usuario']}\n";
            } catch (Exception $e) {
                echo "Erro ao atualizar status online: " . $e->getMessage() . "\n";
            }

            return;
        }

        /* ============================================================
            2) ENVIO DE MENSAGEM
        ============================================================ */
        if ($data['tipo'] === 'mensagem') {

            try {
                // Ajustado para combinar com a estrutura atual do banco
                $stmt = $this->pdo->prepare("
                    INSERT INTO mensagens (remetente, destinatario, mensagem, data_envio, entregue, lido)
                    VALUES (?, ?, ?, NOW(), 1, 0)
                ");

                $stmt->execute([
                    $data['usuario'],
                    $data['destinatario'],
                    $data['mensagem']
                ]);

                echo "Mensagem salva: {$data['usuario']} -> {$data['destinatario']}\n";

                // hora para o front
                $data['hora'] = date("Y-m-d H:i:s");

                // Enviar APENAS para emissor e destinatário
                foreach ($this->clientes as $cliente) {
                    if (
                        $cliente->usuario === $data["destinatario"] || 
                        $cliente->usuario === $data["usuario"]
                    ) {
                        $cliente->send(json_encode($data));
                    }
                }

            } catch (Exception $e) {
                echo "Erro ao salvar mensagem: " . $e->getMessage() . "\n";
            }

            return;
        }

        /* ============================================================
            3) MARCAR COMO LIDO
        ============================================================ */
        if ($data["tipo"] === "lido") {

            try {
                $this->pdo->prepare("
                    UPDATE mensagens
                    SET lido = 1
                    WHERE remetente = ? AND destinatario = ?
                ")->execute([
                    $data["remetente"],
                    $data["destinatario"]
                ]);

                echo "Mensagens marcadas como lidas: {$data['remetente']} -> {$data['destinatario']}\n";

                // notifica quem enviou
                foreach ($this->clientes as $cliente) {
                    if ($cliente->usuario === $data["remetente"]) {
                        $cliente->send(json_encode([
                            "tipo" => "lido",
                            "remetente" => $data["remetente"],
                            "destinatario" => $data["destinatario"]
                        ]));
                    }
                }

            } catch (Exception $e) {
                echo "Erro ao marcar como lido: " . $e->getMessage() . "\n";
            }

            return;
        }

        /* ============================================================
            4) DIGITANDO
        ============================================================ */
        if ($data["tipo"] === "digitando" || $data["tipo"] === "parou") {

            foreach ($this->clientes as $cliente) {
                if ($cliente !== $from && $cliente->usuario === $data["para"]) {
                    $cliente->send(json_encode($data));
                }
            }

            return;
        }
    }

    public function onClose(ConnectionInterface $conn)
    {
        if ($conn->usuario) {
            /*Offiline */
            try {
                $this->pdo->prepare("UPDATE usuarios SET online = 0 WHERE nome = ?")
                    ->execute([$conn->usuario]);
                echo "Usuário desconectado: {$conn->usuario}\n";
            } catch (Exception $e) {
                echo "Erro ao atualizar status offline: " . $e->getMessage() . "\n";
            }
        }

        $this->clientes->detach($conn);
        echo "Conexão encerrada: {$conn->resourceId}\n";
    }

    public function onError(ConnectionInterface $conn, Exception $e)
    {
        $conn->close();
        echo "Erro: {$e->getMessage()}\n";
    }
}