<?php
    include_once 'conexaoMySQL.php';
    session_start();

    $desc = $_POST['desc'] ?? '';
    $data = $_POST['data'] ?? '';
    $horario = $_POST['horario'] ?? '';
    $bairro = $_POST['bairro'] ?? '';
    $logradouro = $_POST['logradouro'] ?? '';
    $numero = $_POST['numero'] ?? '';
    $complemento = $_POST['complemento'] ?? '';
    $metodoPagamento = $_POST['pagamento'] ?? '';

    $prestador = $_GET['id'] ?? 1;

    // Verificar se o usuário está logado
    if (!isset($_SESSION['usuario'])) {
        // Redirecionar para a página de login se não estiver logado
        header('location: login.html');
        exit();
    }
    else {
        $sql_insert = "INSERT INTO servico (bairro, logradouro, numero, complemento, dataServico, tipoPagamento, descricao, contrato, prestador, cliente) VALUES (?, ?, ?, ?, ?, ?, ?, 'pendente', ?, ?)";
        $stmt = $conexao->prepare($sql_insert);
        if (!$stmt) {
            echo "Erro ao preparar o SQL: " . $conexao->error;
            exit;
        }
        $stmt->bind_param('sssssssss',$bairro,$logradouro, $numero, $complemento, $data, $metodoPagamento, $desc, $prestador, $_SESSION['usuario']);

        if($stmt->execute()) {
            echo "Serviço contratado com sucesso!";
            //header('Location: ../perfil.php');
            exit();
        }
        else {
            echo "Erro ao contratar o serviço: " . $stmt->error;
            exit();
        }
    }
?>