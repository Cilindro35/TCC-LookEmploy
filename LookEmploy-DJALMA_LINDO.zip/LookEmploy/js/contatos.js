/* ===========================================================
   CONFIGURAÇÕES INICIAIS
=========================================================== */

// Validação do usuário atual
if (!CURRENT_USER || CURRENT_USER === "null") {
    alert("Sessão expirada. Faça login novamente.");
    window.location.href = "login.html";
}

const ws = new WebSocket("ws://localhost:8080");

/* ELEMENTOS */
const chat = document.getElementById("chatMensagens");
const campoBusca = document.getElementById("buscarContato");
const listaUsuariosEl = document.getElementById("listaUsuarios");
const btnEnviar = document.getElementById("btnEnviar");
const inputMensagem = document.getElementById("mensagem");
const nomeTopo = document.getElementById("nomeContatoAtual");
const digitandoArea = document.getElementById("digitandoArea");

/* ESTADO DO SISTEMA */
let contactsMap = {};     // nome → dados do contato
let activeContact = null; // contato atualmente aberto
let typingTimeoutMap = {}; // timeout de "digitando"
let wsReady = false;      // WebSocket pronto para uso


/* ===========================================================
   INICIALIZAÇÃO DOS CONTATOS DO DOM
=========================================================== */

function initContactsFromDOM() {
    document.querySelectorAll(".usuario").forEach(li => {
        const name = li.dataset.usuario.trim();

        contactsMap[name] = {
            name,
            lastMsg: li.querySelector(".ultima-msg")?.textContent || "",
            lastTimeISO: null,
            unreadCount: 0,
            online: li.querySelector(".dot-online") ? true : false,
            el: li
        };

        ensureBadge(li);
    });
}

function ensureBadge(li) {
    if (!li.querySelector(".badge-unread")) {
        const badge = document.createElement("div");
        badge.className = "badge-unread";
        badge.style.display = "none";
        li.appendChild(badge);
    }
}


/* ===========================================================
   RENDERIZAÇÃO DOS CONTATOS
=========================================================== */

function renderContactLine(contact) {
    const li = contact.el;

    // Atualizar mensagem
    const ultimaMsgEl = li.querySelector(".ultima-msg");
    if (ultimaMsgEl) {
        ultimaMsgEl.textContent = contact.lastMsg || "Última mensagem";
    }

    // Atualizar hora
    const horaEl = li.querySelector(".hora-nome");
    if (horaEl) {
        horaEl.textContent = contact.lastTimeISO
            ? new Date(contact.lastTimeISO).toLocaleTimeString("pt-BR", { 
                hour: "2-digit", 
                minute: "2-digit" 
            })
            : "";
    }

    // BADGE
    const badge = li.querySelector(".badge-unread");
    if (badge) {
        if (contact.unreadCount > 0) {
            badge.textContent = contact.unreadCount > 99 ? "99+" : contact.unreadCount;
            badge.style.display = "block";
        } else {
            badge.style.display = "none";
        }
    }

    // ONLINE/OFFLINE
    if (contact.online) {
        li.querySelector(".dot-offline")?.remove();
        if (!li.querySelector(".dot-online")) {
            const dot = document.createElement("div");
            dot.className = "dot-online";
            li.appendChild(dot);
        }
    } else {
        li.querySelector(".dot-online")?.remove();
        if (!li.querySelector(".dot-offline")) {
            const dot = document.createElement("div");
            dot.className = "dot-offline";
            li.appendChild(dot);
        }
    }
}


/* ===========================================================
   ORGANIZAÇÃO DA LISTA DE CONTATOS
=========================================================== */

function reorderContactList() {
    const list = Object.values(contactsMap);

    list.sort((a, b) => {
        if (!a.lastTimeISO && !b.lastTimeISO) return a.name.localeCompare(b.name);
        if (!a.lastTimeISO) return 1;
        if (!b.lastTimeISO) return -1;
        return new Date(b.lastTimeISO) - new Date(a.lastTimeISO);
    });

    list.forEach(c => listaUsuariosEl.appendChild(c.el));
}


/* ===========================================================
   FORMATOS DE DATA
=========================================================== */

function formatarDataMensagem(data) {
    const hoje = new Date();
    const ontem = new Date();
    ontem.setDate(ontem.getDate() - 1);

    const d = new Date(data);

    if (d.toDateString() === hoje.toDateString()) return "Hoje";
    if (d.toDateString() === ontem.toDateString()) return "Ontem";

    return d.toLocaleDateString("pt-BR");
}

function inserirSeparadorSeNecessario(dataISO) {
    const label = formatarDataMensagem(dataISO);
    const ultimo = chat.querySelector(".separador-data:last-of-type");

    if (!ultimo || ultimo.dataset.data !== label) {
        chat.insertAdjacentHTML(
            "beforeend",
            `<div class="separador-data" data-data="${label}"><span>${label}</span></div>`
        );
    }
}


/* ===========================================================
   HISTÓRICO DE MENSAGENS
=========================================================== */

function carregarHistorico(contato) {
    if (!contato) return;

    fetch(`carregar_historico.php?contato=${contatoId}`)
        .then(r => {
            if (!r.ok) throw new Error("Erro ao carregar histórico");
            return r.text(); // Pega como texto primeiro
        })
        .then(text => {
            chat.innerHTML = "";

            // Se estiver vazio, não há histórico
            if (!text || text.trim() === "") {
                console.log("Nenhum histórico encontrado para", contato);
                chat.scrollTop = chat.scrollHeight;
                return;
            }

            // Tenta fazer parse do JSON
            let msgs;
            try {
                msgs = JSON.parse(text);
            } catch (e) {
                console.error("JSON inválido recebido:", text);
                throw new Error("Resposta inválida do servidor");
            }

            // Verifica se há erro na resposta
            if (msgs.error) {
                console.error("Erro do servidor:", msgs.error);
                return;
            }

            // Adiciona mensagens se existirem
            if (msgs && Array.isArray(msgs) && msgs.length > 0) {
                msgs.forEach(m =>
                    adicionarMensagem({
                        tipo: m.remetente === CURRENT_USER ? "enviada" : "recebida",
                        mensagem: m.mensagem,
                        hora: m.data_envio
                    })
                );
            }

            chat.scrollTop = chat.scrollHeight;
        })
        .catch(err => {
            console.error("Erro ao carregar histórico:", err);
            chat.innerHTML = '<div style="text-align: center; color: #888; padding: 20px;">Erro ao carregar mensagens</div>';
        });
}


/* ===========================================================
   ADICIONAR MENSAGEM AO CHAT
=========================================================== */

function escapeHtml(str) {
    return String(str)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#39;");
}

function adicionarMensagem(info) {
    const horaFmt = new Date(info.hora).toLocaleTimeString("pt-BR", {
        hour: "2-digit",
        minute: "2-digit"
    });

    inserirSeparadorSeNecessario(info.hora);

    const html = `
        <div class="${info.tipo === "enviada" ? "msg-enviada" : "msg-recebida"}">
            <span>${escapeHtml(info.mensagem)}</span>
            <div class="infos-msg"><span class="hora">${horaFmt}</span></div>
        </div>
    `;

    chat.insertAdjacentHTML("beforeend", html);
    chat.scrollTop = chat.scrollHeight;
}


/* ===========================================================
   ATUALIZAR PREVIEW DO CONTATO
=========================================================== */

function atualizarPreview(contato, mensagem, horaISO, incrementarUnread = true) {
    const c = contactsMap[contato];
    if (!c) return;

    c.lastMsg = mensagem;
    c.lastTimeISO = horaISO;

    if (incrementarUnread && activeContact !== contato) {
        c.unreadCount++;
    }

    renderContactLine(c);
    reorderContactList();
}


/* ===========================================================
   EVENTOS DO WEBSOCKET
=========================================================== */

ws.onopen = () => {
    console.log("WebSocket conectado");
    wsReady = true;
    
    // IMPORTANTE: Enviar login primeiro
    ws.send(JSON.stringify({ 
        tipo: "login", 
        usuario: CURRENT_USER
    }));
};

ws.onerror = (error) => {
    console.error("Erro no WebSocket:", error);
};

ws.onclose = () => {
    console.log("WebSocket desconectado");
    wsReady = false;
    setTimeout(() => {
        alert("Conexão perdida. Recarregue a página.");
    }, 2000);
};

ws.onmessage = evt => {
    const data = JSON.parse(evt.data);

    /* MENSAGEM RECEBIDA */
    if (data.tipo === "mensagem") {
        const remetente = data.usuario;
        const destinatario = data.destinatario;

        const isFromMe = remetente === CURRENT_USER;
        const isForMe = destinatario === CURRENT_USER;

        const isOpenChat =
            activeContact === remetente || activeContact === destinatario;

        atualizarPreview(
            isForMe ? remetente : destinatario,
            data.mensagem,
            data.hora,
            !isOpenChat
        );

        if (isOpenChat) {
            adicionarMensagem({
                tipo: isFromMe ? "enviada" : "recebida",
                mensagem: data.mensagem,
                hora: data.hora
            });

            if (isForMe && activeContact === remetente) {
                ws.send(
                    JSON.stringify({
                        tipo: "lido",
                        remetente: remetente,
                        destinatario: CURRENT_USER
                    })
                );
                contactsMap[remetente].unreadCount = 0;
                renderContactLine(contactsMap[remetente]);
            }
        }
    }

    /* DIGITANDO */
    if (data.tipo === "digitando" && data.usuario !== CURRENT_USER) {
        if (activeContact === data.usuario) {
            digitandoArea.textContent = `${data.usuario} está digitando...`;
            clearTimeout(typingTimeoutMap[data.usuario]);

            typingTimeoutMap[data.usuario] = setTimeout(() => {
                digitandoArea.textContent = "";
            }, 1500);
        }
    }

    if (data.tipo === "parou") {
        digitandoArea.textContent = "";
    }

    /* STATUS ONLINE */
    if (data.tipo === "status") {
        if (contactsMap[data.usuario]) {
            contactsMap[data.usuario].online = data.status === "online";
            renderContactLine(contactsMap[data.usuario]);
        }
    }
};


/* ===========================================================
   ENVIO DE MENSAGENS
=========================================================== */

function enviarMensagem(destinatario, texto) {
    if (!wsReady || ws.readyState !== WebSocket.OPEN) {
        alert("Aguardando conexão. Tente novamente em instantes.");
        return;
    }

    ws.send(
        JSON.stringify({
            tipo: "mensagem",
            usuario: CURRENT_USER,
            destinatario,
            mensagem: texto,
            hora: new Date().toISOString()
        })
    );
}

btnEnviar.addEventListener("click", () => {
    if (!activeContact) {
        alert("Selecione um contato.");
        return;
    }
    
    const texto = inputMensagem.value.trim();
    if (!texto) return;

    enviarMensagem(activeContact, texto);

    adicionarMensagem({
        tipo: "enviada",
        mensagem: texto,
        hora: new Date().toISOString()
    });

    atualizarPreview(activeContact, texto, new Date().toISOString(), false);

    inputMensagem.value = "";
    inputMensagem.focus();
});

inputMensagem.addEventListener("keydown", e => {
    if (e.key === "Enter" && !e.shiftKey) {
        e.preventDefault();
        btnEnviar.click();
    } else if (activeContact && e.key !== "Enter" && wsReady && ws.readyState === WebSocket.OPEN) {
        ws.send(
            JSON.stringify({
                tipo: "digitando",
                usuario: CURRENT_USER,
                destinatario: activeContact
            })
        );
    }
});


/* ===========================================================
   TROCAR CONTATO
=========================================================== */

function setupContactClickHandlers() {
    document.querySelectorAll(".usuario").forEach(li => {
        li.addEventListener("click", () => {
            document.querySelectorAll(".usuario").forEach(u => u.classList.remove("ativo"));
            li.classList.add("ativo");

            activeContact = li.dataset.usuario;
            nomeTopo.textContent = activeContact;
            digitandoArea.textContent = "";

            if (contactsMap[activeContact]) {
                contactsMap[activeContact].unreadCount = 0;
                renderContactLine(contactsMap[activeContact]);

                // Enviar "lido" só se WebSocket estiver pronto
                if (wsReady && ws.readyState === WebSocket.OPEN) {
                    ws.send(
                        JSON.stringify({
                            tipo: "lido",
                            remetente: activeContact,
                            destinatario: CURRENT_USER
                        })
                    );
                }
            }

            carregarHistorico(activeContact);
            inputMensagem.focus();
        });
    });
}


/* ===========================================================
   BUSCA DE CONTATOS
=========================================================== */

campoBusca.addEventListener("input", () => {
    const termo = campoBusca.value.toLowerCase().trim();
    document.querySelectorAll(".usuario").forEach(u => {
        const nome = u.querySelector(".nome").textContent.toLowerCase();
        u.style.display = nome.includes(termo) ? "flex" : "none";
    });
});


/* ===========================================================
   INICIALIZAÇÃO FINAL
=========================================================== */

initContactsFromDOM();
setupContactClickHandlers();
Object.values(contactsMap).forEach(renderContactLine);
reorderContactList();

/* Selecionar primeiro contato automaticamente */
const first = document.querySelector(".usuario");
if (first) {
    first.click();
}