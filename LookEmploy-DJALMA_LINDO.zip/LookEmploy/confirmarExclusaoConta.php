<form action="php/excluirConta.php" method="post">
    <h2>Excluir a Conta?</h2>
    <input type="submit" value="Confirmar exclusão">
    <button id="cancelarExclusao">Cancelar</button>
</form>