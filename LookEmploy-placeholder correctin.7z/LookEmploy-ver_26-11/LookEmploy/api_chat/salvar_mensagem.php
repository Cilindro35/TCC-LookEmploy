<?php
require "conectar.php";

$remetente = $_POST["remetente"];
$destinatario = $_POST["destinatario"];
$mensagem = $_POST["mensagem"];

$sql = $pdo->prepare("
    INSERT INTO mensagens (remetente, destinatario, mensagem)
    VALUES (?, ?, ?)
");
$sql->execute([$remetente, $destinatario, $mensagem]);

echo json_encode(["ok" => true]);
