<?php
session_start();
require "conectar.php";

$usuario = $_SESSION["usuario"];

$sql = $pdo->prepare("
    SELECT 
        u.nome,
        u.online,
        (
            SELECT mensagem 
            FROM mensagens m 
            WHERE (m.remetente = u.nome AND m.destinatario = ?)
               OR (m.destinatario = u.nome AND m.remetente = ?)
            ORDER BY m.data_envio DESC
            LIMIT 1
        ) AS ultima_msg,

        (
            SELECT data_envio
            FROM mensagens m 
            WHERE (m.remetente = u.nome AND m.destinatario = ?)
               OR (m.destinatario = u.nome AND m.remetente = ?)
            ORDER BY m.data_envio DESC
            LIMIT 1
        ) AS ultima_hora,

        (
            SELECT COUNT(*) 
            FROM mensagens m
            WHERE m.remetente = u.nome 
              AND m.destinatario = ?
              AND m.lido = 0
        ) AS nao_lidas

    FROM usuarios u
    WHERE u.nome != ?
    ORDER BY ultima_hora DESC
");
$sql->execute([$usuario, $usuario, $usuario, $usuario, $usuario, $usuario]);

echo json_encode($sql->fetchAll(PDO::FETCH_ASSOC));
