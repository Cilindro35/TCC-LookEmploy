<?php
session_start();
require "conectar.php";

$usuario = $_SESSION["usuario"];
$contato = $_POST["contato"];

$sql = $pdo->prepare("
    UPDATE mensagens 
    SET lido = 1
    WHERE remetente = ? AND destinatario = ?
");
$sql->execute([$contato, $usuario]);

echo json_encode(["ok" => true]);
