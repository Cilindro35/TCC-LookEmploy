<?php
// Adicione no TOPO do arquivo para ver erros como JSON
header('Content-Type: application/json; charset=utf-8');
error_reporting(0); // Desabilita exibição de erros HTML

session_start();

// Verifica se usuário está logado
if (!isset($_SESSION['usuario'])) {
    echo json_encode(['error' => 'Não autenticado']);
    exit();
}

// Verifica se contato foi passado
if (!isset($_GET['contato'])) {
    echo json_encode([]);
    exit();
}

$contato = $_GET['contato'];
$usuario_atual = $_SESSION['usuario'];

try {
    require_once 'conectar.php';
    
    $stmt = $pdo->prepare("
        SELECT remetente, mensagem, data_envio 
        FROM mensagens 
        WHERE (remetente = ? AND destinatario = ?) 
           OR (remetente = ? AND destinatario = ?)
        ORDER BY data_envio ASC
    ");
    
    $stmt->execute([$usuario_atual, $contato, $contato, $usuario_atual]);
    $mensagens = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode($mensagens);
    
} catch (Exception $e) {
    echo json_encode(['error' => $e->getMessage()]);
}
?>