<?php
// Script para cadastrar os usuários no banco 'chat'
header('Content-Type: text/html; charset=utf-8');

// Conexão direta com o banco
try {
    $pdo = new PDO(
        "mysql:host=localhost;dbname=chat;charset=utf8mb4", 
        "root", 
        "",
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
        ]
    );
} catch (PDOException $e) {
    die("Erro de conexão: " . $e->getMessage());
}

echo "<h1>Cadastro de Usuários no Banco Chat</h1>";

// Lista de usuários para cadastrar
$usuarios = [
    'Davi Britto',
    'Juliette Freire'
];

echo "<h2>Cadastrando usuários...</h2>";

foreach ($usuarios as $nome) {
    try {
        // Verifica se já existe
        $stmt = $pdo->prepare("SELECT id FROM usuarios WHERE nome = ?");
        $stmt->execute([$nome]);
        
        if ($stmt->fetch()) {
            echo "<p>✓ Usuário '<strong>$nome</strong>' já existe</p>";
        } else {
            // Insere novo usuário
            $stmt = $pdo->prepare("INSERT INTO usuarios (nome, online) VALUES (?, 0)");
            $stmt->execute([$nome]);
            echo "<p>✓ Usuário '<strong>$nome</strong>' cadastrado com sucesso</p>";
        }
    } catch (Exception $e) {
        echo "<p style='color: red;'>✗ Erro ao cadastrar '$nome': {$e->getMessage()}</p>";
    }
}

echo "<hr>";
echo "<h2>Usuários cadastrados no banco:</h2>";

$usuarios = $pdo->query("SELECT * FROM usuarios")->fetchAll();
echo "<table border='1' cellpadding='5'>";
echo "<tr><th>ID</th><th>Nome</th><th>Online</th></tr>";
foreach ($usuarios as $u) {
    echo "<tr>";
    echo "<td>{$u['id']}</td>";
    echo "<td>{$u['nome']}</td>";
    echo "<td>" . ($u['online'] ? 'Sim' : 'Não') . "</td>";
    echo "</tr>";
}
echo "</table>";

echo "<br><a href='contatos.php'>Voltar ao Chat</a>";
?>