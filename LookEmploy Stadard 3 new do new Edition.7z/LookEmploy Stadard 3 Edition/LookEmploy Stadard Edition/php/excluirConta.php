<?php

include_once 'conexaoMySQL.php';
session_start();

    // Verificar se o usuário está logado
    if (!isset($_SESSION['usuario'])) {
        // Redirecionar para a página de login se não estiver logado
        header('location: login.html');
        exit();
    }
        //conexão com o banco de dados
        $conexao = new mysqli('localhost', 'root', '', 'lookemploy');
        if ($conexao->connect_error) {
            echo("Erro de conexão: " . $conexao->connect_error);
            header('location: perfil.php');
            exit;
        }
        
          $tipo = $_SESSION['tipo'];
          $ID = $_SESSION['usuario'];
          $sql = "DELETE FROM $tipo WHERE ID = ?";
          $stmt = $conexao->prepare($sql);

  if (!$stmt) {
      echo "Erro ao preparar o SQL: " . $conexao->error;
      exit;
  }

  // Associa os parâmetros
  $stmt->bind_param("i",$ID);
  // Executa o comando
  if ($stmt->execute()) {
      header("location: login.html");
  } else {
      echo "ERRO: " . $stmt->error;
      header("location: login.html");
      exit;
  }
  $stmt->close();
  $conexao->close();
?>