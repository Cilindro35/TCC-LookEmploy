<?php
    // Iniciar a sessão
    session_start();

    // Verificar se o usuário está logado
    if (!isset($_SESSION['usuario'])) {
        // Redirecionar para a página de login se não estiver logado
        header('location: login.html');
        exit();
    }
    else {
        //pegando o id da URL
        $id = $_GET['id'] ?? 1;

        if(is_numeric($id)) {
            //buscando os dados do prestador no banco de dados
            $conn = new mysqli('localhost', 'root', '', 'lookemploy');
            if ($conn->connect_error) {
                die("Erro de conexão: " . $conn->connect_error);
            }
            else {
                $stmt = $conn->prepare("SELECT nome, descricao, avaliacao FROM prestador WHERE ID = ?");
                $stmt->bind_param("s", $id);
                $stmt->execute();
                $result = $stmt->get_result();

                $row = $result->fetch_assoc();
                if ($row) {
                    $nome = $row["nome"];
                    $descricao = $row["descricao"];
                    $avaliacao = $row["avaliacao"];
                }
            }
        }
        else exit();
    }
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Perfil</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap">
    <link rel="stylesheet" href="css/design_visualizarPrestador.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link rel="icon" type="image/png" href="img/logo_icon.png">
</head>
<body>
    <!--RODAPÉ-->
    <header>
        <nav>
            <a href="index.html"><img src="img/logo.png" style="width: 140px; height: 40px;" alt="LookEmploy"></a>
            <div>
                <!--sininho-->
                <a href="">
                    <img src="img/icone_notificacoes.png" alt="Notificações">
                </a>

                <!--mais-->
                <a href="">
                    <img src="img/icone_mais.png" alt="Mais">
                </a>
            </nav>
        </div>
    </header>

    <!--MENU LATERAL-->
    <section class="menuLateral">
        <!--Inicio-->
        <a class="menuItem" href="telaInicial.php" target="_self">
            <img src="img/icone_inicio.png" alt="Inicio">
            <label>Inicio</label>
        </a>

        <!--Pedidos-->
        <a class="menuItem" href="pedidos.php" target="_self">
            <img src="img/icone_pedidos.png" alt="Pedidos">
            <label>Pedidos</label>
        </a>

        <!--Contatos-->
        <a class="menuItem" href="contatos.php" target="_self">
            <img src="img/icone_contatos.png" alt="Contatos">
            <label>Contatos</label>
        </a>

        <!--Perfil-->
        <a class="menuItem" href="perfil.php" target="_self">
            <img src="img/icone_perfil.png" alt="Perfil">
            <label>Perfil</label>
        </a>
    </section>

    <!--PERFIL-->    
    <section class="perfil">
        <a target="_self" href="telaInicial.php"><button>Voltar</button></a>

        <!--FOTO E OPÇÕES-->
        <section class="secao">
            <!--FOTO E NOME-->
            <div class="informacoes">
                <img class="fotoPerfil" src="img/icone_perfil.png" alt="Foto de perfil">

                <!--NOME E DESCRIÇÃO-->
                <div style="flex-direction: column;">
                    <?php 
                        echo "<h1>". htmlspecialchars($nome)."</h1>"; 
                        if($descricao != null) echo "<p>". htmlspecialchars($descricao)."</p>";
                    ?>

                    <!--avaliação-->
                    <div style="flex-direction: row;">
                        <?php        
                            for($i = 0; $i < $avaliacao; $i++) {
                                echo "<i class='fa-solid fa-star' style='color: #5CE1E6;'></i>";
                            }
                        ?>
                    </div>
                </div>
            </div>

            <div class="botoes">
                <a href=""><button>Chat</button></a>
                <a href=""><button>Contratar</button></a>
            </div>
        </section>
    </section>
</body>
</html>
