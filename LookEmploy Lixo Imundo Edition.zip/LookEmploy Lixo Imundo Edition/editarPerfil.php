<?php
    // Iniciar a sessão
    session_start();

    // Verificar se o usuário está logado
    if (!isset($_SESSION['usuario'])) {
        // Redirecionar para a página de login se não estiver logado
        header('location: login.html');
        exit();
    }
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Perfil</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap">
    <link rel="stylesheet" href="css/design_editarPerfil.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link rel="icon" type="image/png" href="img/logo_icon.png">
</head>
<body>
    <!--RODAPÉ-->
    <header>
        <nav>
            <a href="index.html"><img src="img/logo.png" style="width: 140px; height: 40px;" alt="LookEmploy"></a>
            <div>
                <!--sininho-->
                <a href="">
                    <img src="img/icone_notificacoes.png" alt="Notificações">
                </a>

                <!--mais-->
                <a href="">
                    <img src="img/icone_mais.png" alt="Mais">
                </a>
            </nav>
        </div>
    </header>

    <!--MENU LATERAL-->
    <section class="menuLateral">
        <!--Inicio-->
        <a class="menuItem" href="telaInicial.php" target="_self">
            <img src="img/icone_inicio.png" alt="Inicio">
            <label>Inicio</label>
        </a>

        <!--Pedidos-->
        <a class="menuItem" href="pedidos.php" target="_self">
            <img src="img/icone_pedidos.png" alt="Pedidos">
            <label>Pedidos</label>
        </a>

        <!--Contatos-->
        <a class="menuItem" href="contatos.php" target="_self">
            <img src="img/icone_contatos.png" alt="Contatos">
            <label>Contatos</label>
        </a>

        <!--Perfil-->
        <a class="menuItem" href="perfil.php" target="_self">
            <img src="img/icone_perfil.png" alt="Perfil">
            <label>Perfil</label>
        </a>
    </section>

    <!--PERFIL-->
    <section class="perfil">
        <!--FOTO E OPÇÕES-->
        <section class="secao" style="background: linear-gradient(to top, white 45%, whitesmoke 45%);">
            <div class="informacoes">
                <!--FOTO E NOME-->
                <div class="inicio">
                    <img class="fotoPerfil" src="img/icone_perfil.png" alt="Foto de perfil">
                    <?php echo "<h1>". htmlspecialchars($_SESSION["nome"])."</h1>"; ?>
                </div>
            </div>
        </section>

        <hr style="margin: 16px 10% 16px 10%">

        <!--FORMULARIO DE EDIÇÃO-->
        <section class="secao">
            <form class="formulario" id="formulario" action="php/atualizarDados.php" method="post">
                <div class="column">
                    <h2>Informações</h2>
                    <input type="text" id="nome" name="nome" placeholder="Nome" />
                    <span id="nomeInvalido" style="color: red;"></span>
                    
                    <input type="date" id="dataNascimento" name="dataNascimento" placeholder="Data de Nascimento">
                    <span id="dataNascimentoInvalida" style="color: red;"></span>

                    <h2>Sexo</h2>
                    <div class>
                        <label for="masculino">Masculino</label>
                        <input type="radio" id="masculino" name="sexo" value="Masculino" />
                        <label for="feminino">Feminino</label>
                        <input type="radio" id="feminino" name="sexo" value="Feminino" />
                        <label for="prefiroNaoResponder">Prefiro não responder</label>
                        <input type="radio" id="prefiroNaoResponder" name="sexo" value="Prefiro não responder" />    
                    </div>
                    <span id="sexoInvalido" style="color: red;"></span>

                    <h2>Endereço</h2>
                    <input type="text" id="bairro" name="bairro" placeholder="Bairro" />
                    <span id="bairroInvalido" style="color: red;"></span>
    
                    <input type="text" id="logradouro" name="logradouro" placeholder="Logradouro" />
                    <span id="logradouroInvalido" style="color: red;"></span>
    
                    <input type="text" id="numero" name="numero" placeholder="Número" />
                    <span id="numeroInvalido" style="color: red;"></span>
    
                    <input type="text" id="complemento" name="complemento" placeholder="Complemento" />
                    <span id="complementoInvalido" style="color: red;"></span>

                    <h2>Descrição</h2>
                    <?php
                        if($_SESSION['tipo'] == 'Prestador') {
                            echo "<input type='text' id='servico' name='servico' placeholder='Serviços' />
                            <span id='servicoInvalido' style='color: red;'></span>";
                        }
                    ?>
                    <textarea style="resize: none;" rows="4"  id="desc" name="desc" placeholder="Descrição"></textarea>
                    <span id="descInvalido" style="color: red;"></span>
                </div>

                <div class="column">
                    <!--Botão de voltar-->
                    <div class="row">
                        <a href="perfil.php"><input type="button" value="Voltar"></a>
                        <input type="submit" value="Salvar">
                    </div>
                    <p id="msgSucesso"></p><br>
                    
                    <input type="button" value="Trocar Senha">
                    <input type="button" value="Trocar Email">
                    <input type="button" value="Trocar Telefone"><br>
                    <input type="button" value="Excluir Conta">
                </div>
              </form>
              <!--<script src="js/validacaoCadastro.js"></script>-->
        </section>
    </section>
</body>
</html>
