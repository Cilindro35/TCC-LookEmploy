<?php
  include_once 'conexaoMySQL.php';
 
  $tipo = $_POST['tipo'] ?? '';
  $email = $_POST['email'] ?? '';
  $senha = $_POST['senha'] ?? '';
  $nome = $_POST['nome'] ?? '';
  $telefone = $_POST['telefone'] ?? '';
  $data_nascimento = $_POST['dataNascimento'] ?? '';
  $bairro = $_POST['bairro'] ?? '';
  $logradouro = $_POST['logradouro'] ?? '';
  $numero = $_POST['numero'] ?? '';
  $complemento = $_POST['complemento'] ?? '';
  $sexo = $_POST['sexo'] ?? '';
 
  // Validação básica
  if ($tipo != '' && $nome != '' && $email != '' && $senha != '' && $telefone != '' && $data_nascimento != '' && $bairro != '' && $logradouro != '' && $numero != '' && $complemento != '' && $sexo) {
 
    //criptografia senha
    $senhaHash = password_hash($senha, PASSWORD_DEFAULT);
 
    //codigo de inserção do sql
    $sql = "INSERT INTO $tipo (nome, email, senha, telefone, dataNascimento, bairro, logradouro, numero, complemento, sexo) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conexao->prepare($sql);
 
    if ($stmt === false) {
        echo("Erro ao preparar comando" . $conexao->error);
        exit;
    }
 
    // Liga os parâmetros à query
    $stmt->bind_param("ssssssssss", $nome, $email, $senhaHash, $telefone, $data_nascimento, $bairro, $logradouro, $numero, $complemento, $sexo);
 
    // Executa a query
    if ($stmt->execute()) {
        echo "Cadastro realizado com sucesso!";
    }
    else {
        echo "Erro ao cadastrar: " . $stmt->error;
    }
 
    // Fecha o statement e conexão
    $stmt->close();
    $conexao->close();
  }
  else {
    echo("Erro: dados incompletos.");
    exit;
  }
?>