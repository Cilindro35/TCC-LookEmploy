<?php
  session_start();
  include_once 'conexaoMySQL.php';
 
  $tipo = $_POST['tipo'] ?? '';
  $email = $_POST['email'] ?? '';
  $senha = $_POST['senha'] ?? '';
  $nome = $_POST['nome'] ?? '';
  $telefone = $_POST['telefone'] ?? '';
  $data_nascimento = $_POST['dataNascimento'] ?? '';
  $bairro = $_POST['bairro'] ?? '';
  $logradouro = $_POST['logradouro'] ?? '';
  $numero = $_POST['numero'] ?? '';
  $complemento = $_POST['complemento'] ?? '';
  $sexo = $_POST['sexo'] ?? '';

  function test_input($data) {
    return htmlspecialchars(stripslashes(trim($data)));
  }

  $tipo = $nome = $sobrenome = $email = $senha = $telefone = $data_nascimento = $bairro = $logradouro = $numero = $sexo = "";

  if($_SERVER['REQUEST_METHOD'] == 'POST') {
    if(empty($_POST['email'])) {
      $_SESSION['mensagem'] = ""
    }
  }

  function
 
  //================== conexao com o banco de dados ==========================================

  // Validação básica
  if ($tipo != '' && $nome != '' && $sobrenome != '' && $email != '' && $senha != '' && $telefone != '' && $data_nascimento != '' && $bairro != '' && $logradouro != '' && $numero != '' && $sexo) {
 
    //criptografia senha
    $senhaHash = password_hash($senha, PASSWORD_DEFAULT);

    $sql = "";

    //verificar se o email ja existe
    //faz isso por meio da verificando se ja existe uma conta com esse email
    $verificarConta = "SELECT email FROM $tipo WHERE email = $email";
    $stmt = $conexao->prepare($sql);
    $stmt->bind_param("s", $email);
      if($stm->execute()) {
        if($stmt->get_result() != "") {
          $_SESSION['mensagem'] = "Uma conta com este e-mail já existe! Utlize outro e-mail.";
          header("Location: cadastrar.php");
          exit;
        }
      } else {
        $_SESSION['mensagem'] = "Erro ao cadastrar:";
        echo $stmt->error;
        exit;
      }
    
    //INSERÇÃO DO SQL
    //verificar se complemento (opcional) existe
      switch($complemento) {
        case '':
          $sql = "INSERT INTO $tipo (nome, sobrenome, email, senha, telefone, dataNascimento, bairro, logradouro, numero, sexo) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
          $stmt = $conexao->prepare($sql);
          if ($stmt === false) {
            echo("Erro ao preparar comando" . $conexao->error);
            exit;
        }
        $stmt->bind_param("ssssssssss", $nome, $sobrenome, $email, $senhaHash, $telefone, $data_nascimento, $bairro, $logradouro, $numero, $sexo);
        break;
        default:
          $sql = "INSERT INTO $tipo (nome, sobrenome, email, senha, telefone, dataNascimento, bairro, logradouro, numero, complemento, sexo) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
          $stmt = $conexao->prepare($sql);
          if ($stmt === false) {
            echo("Erro ao preparar comando" . $conexao->error);
            exit;
        }
        $stmt->bind_param("sssssssssss", $nome, $sobrenome, $email, $senhaHash, $telefone, $data_nascimento, $bairro, $logradouro, $numero, $complemento, $sexo);
      }

    // Executa a query
    if ($stmt->execute()) {
        $_SESSION['mensagem'] = "Cadastro realizado com sucesso!";
    }
    else {
        $_SESSION['mensagem'] = "Erro ao cadastrar! Tente novamente";
        echo $stmt->error;
    }
 
    // Fecha o statement e conexão
    $stmt->close();
    $conexao->close();
  }
  else {
    echo("Erro: dados incompletos.");
    exit;
  }
?>