<?php
  session_start();
  include_once 'conexaoMySQL.php';
 
  $tipo = $_POST['tipo'] ?? '';
  $email = $_POST['email'] ?? '';
  $senha = $_POST['senha'] ?? '';
  $nome = $_POST['nome'] ?? '';
  $sobrenome = $_POST['sobrenome'] ?? '';
  $telefone = $_POST['telefone'] ?? '';
  $data_nascimento = $_POST['dataNascimento'] ?? '';
  $bairro = $_POST['bairro'] ?? '';
  $logradouro = $_POST['logradouro'] ?? '';
  $numero = $_POST['numero'] ?? '';
  $complemento = $_POST['complemento'] ?? '';
  $sexo = $_POST['sexo'] ?? '';
  if($tipo == "Prestador") { $servico = $_POST['servico'] ?? ''; }

  function test_input($data) {
    return htmlspecialchars(stripslashes(trim($data)));
  }
 
  //================== conexao com o banco de dados ==========================================

  // Validação básica e sanitização
  $tipo = test_input($tipo);
  $email = test_input($email);
  $senha = test_input($senha);
  $nome = test_input($nome);
  $sobrenome = test_input($sobrenome);
  $telefone = test_input($telefone);
  $data_nascimento = test_input($data_nascimento);
  $bairro = test_input($bairro);
  $logradouro = test_input($logradouro);
  $numero = test_input($numero);
  $complemento = test_input($complemento);
  $sexo = test_input($sexo);

  // Campos obrigatórios
  if (empty($tipo) || empty($nome) || empty($sobrenome) || empty($email) || empty($senha) || empty($telefone) || empty($data_nascimento) || empty($bairro) || empty($logradouro) || empty($numero) || empty($sexo)) {
    echo'Erro: dados incompletos.';
    header('Location: ../cadastro.html');
    exit;
  }

  // Whitelist para tabela (previne SQL injection via nome de tabela)
  $allowed_tables = ['Cliente', 'Prestador'];
  if (!in_array($tipo, $allowed_tables, true)) {
    echo'Tipo de conta inválido.';
    header('Location: ../cadastro.html');
    exit;
  }

  // Criptografia da senha
  $senhaHash = password_hash($senha, PASSWORD_DEFAULT);

  // Verificar se email já existe na tabela correta
  $sql_check = "SELECT email FROM {$tipo} WHERE email = ? LIMIT 1";
  $stmt = $conexao->prepare($sql_check);
  if ($stmt === false) {
    echo'Erro no servidor (prepare).';
    header('Location: ../cadastro.html');
    exit;
  }
  $stmt->bind_param('s', $email);
  if (!$stmt->execute()) {
    echo'Erro ao verificar email: ' . $stmt->error;
    $stmt->close();
    $conexao->close();
    header('Location: ../cadastro.html');
    exit;
  }
  $result = $stmt->get_result();
  if ($result && $result->num_rows > 0) {
   echo'Uma conta com este e-mail já existe! Utilize outro e-mail.';
    $stmt->close();
    $conexao->close();
    header('Location: ../cadastro.html');
    exit;
  }
  $stmt->close();

  //verifica se é prestador para registrar o tipo de servico
  switch ($tipo) {
    case 'Prestador':

      // Preparar INSERT dependendo se complemento está vazio
      if ($complemento === '') {
        $sql_insert = "INSERT INTO {$tipo} (nome, sobrenome, email, senha, telefone, dataNascimento, bairro, logradouro, numero, sexo, tipoServico) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $conexao->prepare($sql_insert);
        if ($stmt === false) {
          echo'Erro no servidor (prepare insert).';
          $conexao->close();
          header('Location: ../cadastro.html');
          exit;
        }
        $stmt->bind_param('sssssssssss', $nome, $sobrenome, $email, $senhaHash, $telefone, $data_nascimento, $bairro, $logradouro, $numero, $sexo, $servico);
      } else {
        $sql_insert = "INSERT INTO {$tipo} (nome, sobrenome, email, senha, telefone, dataNascimento, bairro, logradouro, numero, complemento, sexo, tipoServico) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $conexao->prepare($sql_insert);
        if ($stmt === false) {
          echo'Erro no servidor (prepare insert).';
          $conexao->close();
          header('Location: ../cadastro.html');
          exit;
        }
        $stmt->bind_param('ssssssssssss', $nome, $sobrenome, $email, $senhaHash, $telefone, $data_nascimento, $bairro, $logradouro, $numero, $complemento, $sexo, $servico);
      }   
      break;
      default:
      // Preparar INSERT dependendo se complemento está vazio
      if ($complemento === '') {
        $sql_insert = "INSERT INTO {$tipo} (nome, sobrenome, email, senha, telefone, dataNascimento, bairro, logradouro, numero, sexo) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $conexao->prepare($sql_insert);
        if ($stmt === false) {
          echo'Erro no servidor (prepare insert).';
          $conexao->close();
          header('Location: ../cadastro.html');
          exit;
        }
        $stmt->bind_param('ssssssssss', $nome, $sobrenome, $email, $senhaHash, $telefone, $data_nascimento, $bairro, $logradouro, $numero, $sexo);
      } else {
        $sql_insert = "INSERT INTO {$tipo} (nome, sobrenome, email, senha, telefone, dataNascimento, bairro, logradouro, numero, complemento, sexo) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $conexao->prepare($sql_insert);
        if ($stmt === false) {
          echo'Erro no servidor (prepare insert).';
          $conexao->close();
          header('Location: ../cadastro.html');
          exit;
        }
        $stmt->bind_param('sssssssssss', $nome, $sobrenome, $email, $senhaHash, $telefone, $data_nascimento, $bairro, $logradouro, $numero, $complemento, $sexo);
      }   
      break;
  }

  if ($stmt->execute()) {
    echo'Cadastro realizado com sucesso!';
    $stmt->close();
    $conexao->close();
    header('Location: ../login.html');
    exit;
  } else {
    echo'Erro ao cadastrar! Tente novamente.';
    error_log('DB insert error: ' . $stmt->error);
    $stmt->close();
    $conexao->close();
    header('Location: ../cadastro.html');
    exit;
  }
?>