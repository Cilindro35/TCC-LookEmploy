var formulario = document.getElementById('formulario');
var tipoInput = document.getElementById('tipo');
var nomeInput = document.getElementById('nome');
var sobrenomeInput = document.getElementById('sobrenome');
var telefoneInput = document.getElementById('telefone');
var bairroInput = document.getElementById('bairro');
var logradouroInput = document.getElementById('logradouro');
var numeroInput = document.getElementById('numero');
var complementoInput = document.getElementById('complemento');
var descricaoInput = document.getElementById('desc');

var nomeErro = document.getElementById('nomeInvalido');
var sobrenomeErro = document.getElementById('sobrenomeInvalido');
var telefoneErro = document.getElementById('telefoneInvalido');
var bairroErro = document.getElementById('bairroInvalido');
var logradouroErro = document.getElementById('logradouroInvalido');
var numeroErro = document.getElementById('numeroInvalido');
var complementoErro = document.getElementById('complementoInvalido');
var descricaoErro = document.getElementById('descInvalida');
var msgSucesso = document.getElementById('msgSucesso');

const padraoLetra = /[a-zA-Z]/;
const padraoNumero = /[0-9]/;
const regex = /^\(?\d{2}\)?\s?\d{4,5}-?\d{4}$/;

//filtro do telefone
telefoneInput.addEventListener("input", function (e) {
  let valor = e.target.value.replace(/\D/g, ""); // remove tudo que não é número

  if (valor.length > 10) {
    // celular com 9 dígitos
    valor = valor.replace(/^(\d{2})(\d{5})(\d{4}).*/, "($1) $2-$3");
  } else if (valor.length > 6) {
    // fixo com 8 dígitos
    valor = valor.replace(/^(\d{2})(\d{4})(\d{0,4}).*/, "($1) $2-$3");
  } else if (valor.length > 2) {
    // apenas DDD + começo do número
    valor = valor.replace(/^(\d{2})(\d{0,5})/, "($1) $2");
  } else {
    // só o DDD
    valor = valor.replace(/^(\d*)/, "($1");
  }

  e.target.value = valor;
});

// ---------- VALIDAÇÕES ----------

function validarNome(nome) {
  if (nome.trim() === "") {
    nomeErro.textContent = "Preencha o campo do nome*";
    return false;
  }
  if (nome.length < 3) {
    nomeErro.textContent = "O nome deve ter pelo menos 3 caracteres*";
    return false;
  }
  nomeErro.textContent = "";
  return true;
}

function validarSobrenome(sobrenome) {
  if (sobrenome.trim() === "") {
    sobrenomeErro.textContent = "Preencha o campo do sobrenome*";
    return false;
  }
  if (sobrenome.length < 3) {
    sobrenomeErro.textContent = "O sobrenome deve ter pelo menos 3 caracteres*";
    return false;
  }
  sobrenomeErro.textContent = "";
  return true;
}

function validarTelefone(telefone) {
  if (telefone === "") {
    telefoneErro.textContent = "Preencha o campo do telefone*";
    return false;
  }
  if (!regex.test(telefone)) {
    telefoneErro.textContent = "Telefone inválido*";
    return false;
  }
  telefoneErro.textContent = "";
  return true;
}

function validarBairro(bairro) {
  if (bairro.trim() === "") {
    bairroErro.textContent = "Preencha o campo do bairro*";
    return false;
  }
  if (bairro.length < 3) {
    bairroErro.textContent = "O bairro deve conter pelo menos 3 caracteres*";
    return false;
  }
  bairroErro.textContent = "";
  return true;
}

function validarLogradouro(logradouro) {
  if (logradouro.trim() === "") {
    logradouroErro.textContent = "Preencha o campo do logradouro*";
    return false;
  }
  if (logradouro.length < 3) {
    logradouroErro.textContent = "O logradouro deve conter pelo menos 3 caracteres*";
    return false;
  }
  logradouroErro.textContent = "";
  return true;
}

function validarNumero(numero) {
  if (numero.trim() === "") {
    numeroErro.textContent = "Preencha o campo do número*";
    return false;
  }
  if (!/^\d+$/.test(numero)) {
    numeroErro.textContent = "O número deve conter apenas dígitos*";
    return false;
  }
  numeroErro.textContent = "";
  return true;
}

function validarComplemento(complemento) {
  // Complemento é opcional, mas caso seja preenchido, deve ter no máximo 50 caracteres
  if (complemento.length > 50) {
    complementoErro.textContent = "O complemento deve ter no máximo 50 caracteres*";
    return false;
  }
  complementoErro.textContent = "";
  return true;
}

function validarDescricao(descricao) {
  if (descricao.replace(/\s+/g, "") === "") {
    descricaoErro.textContent = "Preencha o campo*";
    return false;
  }
  descricaoErro.textContent = "";
  return true;
}

// ---------- ENVIO DO FORMULÁRIO ----------

//form para clientes
async function enviarFormulario(tipo, nome, sobrenome, telefone, bairro, logradouro, numero, complemento, descricao) {
  const dados = new FormData();
  dados.append("tipo", tipo);
  dados.append("nome", nome);
  dados.append("sobrenome", sobrenome);
  dados.append("telefone", telefone.replace(/\D/g, ''));
  dados.append("bairro", bairro);
  dados.append("logradouro", logradouro);
  dados.append("numero", numero);
  dados.append("complemento", complemento);
  dados.append("descricao", descricao);

  try {
    msgSucesso.innerHTML = "<p style='color:lightblue'>Enviando...</p>";

    var resposta = await fetch("./php/atualizarDados.php", {
      method: "POST",
      body: dados,
    });

    var texto = await resposta.text();
    console.log(texto);

    msgSucesso.innerHTML = "<p style='color:lightgreen'>Dados atualizados com sucesso!</p>";
  } catch (erro) {
    console.error("Erro ao enviar:", erro);
    msgSucesso.innerHTML = "<p style='color:red'>Erro ao atualizar dados. Tente novamente.</p>";
  }
}

//form para prestadores
async function enviarFormularioPrestador(tipo, nome, sobrenome, telefone, bairro, logradouro, numero, complemento, servico, descricao) {
  const dados = new FormData();
  dados.append("tipo", tipo);
  dados.append("nome", nome);
  dados.append("sobrenome", sobrenome);
  dados.append("telefone", telefone.replace(/\D/g, ''));
  dados.append("bairro", bairro);
  dados.append("logradouro", logradouro);
  dados.append("numero", numero);
  dados.append("complemento", complemento);
  dados.append("servico", servico);
  dados.append("descricao", descricao);

  try {
    msgSucesso.innerHTML = "<p style='color:lightblue'>Enviando...</p>";

    var resposta = await fetch("./php/atualizarDados.php", {
      method: "POST",
      body: dados,
    });

    var texto = await resposta.text();
    console.log(texto);

    msgSucesso.innerHTML = "<p style='color:lightgreen'>Dados atualizados com sucesso!</p>";
  } catch (erro) {
    console.error("Erro ao enviar:", erro);
    msgSucesso.innerHTML = "<p style='color:red'>Erro ao atualizar dados. Tente novamente.</p>";
  }
}

// ---------- SUBMIT ----------

formulario.addEventListener('submit', function(event) {
  event.preventDefault();

  var tipo = tipoInput.value;
  var nome = nomeInput.value.trim();
  var sobrenome = sobrenomeInput.value.trim();
  var telefone = telefoneInput.value.trim();
  var bairro = bairroInput.value.trim();
  var logradouro = logradouroInput.value.trim();
  var numero = numeroInput.value.trim();
  var complemento = complementoInput.value.trim();
  var descricao = descricaoInput.value;
  if(tipo == "Prestador") { var servico = document.querySelector('input[name="servico"]:checked').value; }
  
  var nomeValido = validarNome(nome);
  var sobrenomeValido = validarSobrenome(sobrenome);
  var telefoneValido = validarTelefone(telefone);
  var bairroValido = validarBairro(bairro);
  var logradouroValido = validarLogradouro(logradouro);
  var numeroValido = validarNumero(numero);
  var complementoValido = validarComplemento(complemento);
  var descricaoValida = validarDescricao(descricao);

  if (
    nomeValido &&
    sobrenomeValido &&
    telefoneValido &&
    bairroValido &&
    logradouroValido &&
    numeroValido &&
    complementoValido &&
    descricaoValida
  ) {
    if(tipo == "Prestador" && servico) {
      enviarFormularioPrestador(tipo, nome, sobrenome, telefone, bairro, logradouro, numero, complemento, servico, descricao);
      console.log(tipo);
    } else {
      enviarFormulario(tipo, nome, sobrenome, telefone, bairro, logradouro, numero, complemento, descricao);
      console.log(tipo);
    }
  } else {
    msgSucesso.innerHTML = "<p style='color:red'>Dados incompletos.</p>";
  }
});
