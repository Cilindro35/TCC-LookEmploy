const formulario = document.getElementById('formulario');
const tipoInput = document.getElementById('tipo');
const emailInput = document.getElementById('email');
const senhaInput = document.getElementById('senha');
const nomeInput = document.getElementById('nome');
const rgInput = document.getElementById('rg');
const telefoneInput = document.getElementById('telefone');
const dataNascimentoInput = document.getElementById('dataNascimento');
const bairroInput = document.getElementById('bairro');
const logradouroInput = document.getElementById('logradouro');
const numeroInput = document.getElementById('numero');
const complementoInput = document.getElementById('complemento');

const emailErro = document.getElementById('emailInvalido');
const senhaErro = document.getElementById('senhaInvalida');
const nomeErro = document.getElementById('nomeInvalido');
const rgErro = document.getElementById('rgInvalido');
const telefoneErro = document.getElementById('telefoneInvalido');
const dataNascimentoErro = document.getElementById('dataNascimentoInvalida');
const bairroErro = document.getElementById('bairroInvalido');
const logradouroErro = document.getElementById('logradouroInvalido');
const numeroErro = document.getElementById('numeroInvalido');
const complementoErro = document.getElementById('complementoInvalido');
const msgSucesso = document.getElementById('msgSucesso');

const padraoEmail = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
const padraoLetra = /[a-zA-Z]/;
const padraoNumero = /[0-9]/;

// ---------- VALIDAÇÕES ----------

function validarEmail(email) {
  if (email === "") {
    emailErro.textContent = "Preencha o campo do e-mail*";
    return false;
  }
  if (!padraoEmail.test(email)) {
    emailErro.textContent = "E-mail inválido*";
    return false;
  }
  emailErro.textContent = "";
  return true;
}

function validarSenha(senha) {
  if (senha === "") {
    senhaErro.textContent = "Preencha o campo da senha*";
    return false;
  }
  if (senha.length < 6 || !padraoLetra.test(senha) || !padraoNumero.test(senha)) {
    senhaErro.textContent = "A senha deve conter letras, números e ter no mínimo 6 caracteres*";
    return false;
  }
  senhaErro.textContent = "";
  return true;
}

function validarNome(nome) {
  if (nome.trim() === "") {
    nomeErro.textContent = "Preencha o campo do nome*";
    return false;
  }
  if (nome.length < 3) {
    nomeErro.textContent = "O nome deve ter pelo menos 3 caracteres*";
    return false;
  }
  nomeErro.textContent = "";
  return true;
}

function validarRG(rg) {
  const rgFormatado = rg.replace(/\D/g, '');
  if (rgFormatado === "") {
    rgErro.textContent = "Preencha o campo do RG*";
    return false;
  }
  if (rgFormatado.length < 7 || rgFormatado.length > 12) {
    rgErro.textContent = "RG inválido* (deve conter 7 a 12 dígitos)";
    return false;
  }
  rgErro.textContent = "";
  return true;
}

function validarTelefone(telefone) {
  if (telefone === "") {
    telefoneErro.textContent = "Preencha o campo do telefone*";
    return false;
  }
  telefoneErro.textContent = "";
  return true;
}

function validarDataNascimento(dataNascimento) {
  if (!dataNascimento) {
    dataNascimentoErro.textContent = "Preencha o campo da data de nascimento*";
    return false;
  }

  const nascimento = new Date(dataNascimento);
  const hoje = new Date();

  let idade = hoje.getFullYear() - nascimento.getFullYear();
  let mes = hoje.getMonth() - nascimento.getMonth();

  if (
    idade < 0 ||
    (idade === 0 && mes < 0) ||
    nascimento > hoje
  ) {
    dataNascimentoErro.textContent = "Data de nascimento inválida*";
    return false;
  }

  if (idade < 18 || (idade === 18 && mes < 0)) {
    dataNascimentoErro.textContent = "Você deve ter pelo menos 18 anos*";
    return false;
  }

  dataNascimentoErro.textContent = "";
  return true;
}

function validarBairro(bairro) {
  if (bairro.trim() === "") {
    bairroErro.textContent = "Preencha o campo do bairro*";
    return false;
  }
  if (bairro.length < 3) {
    bairroErro.textContent = "O bairro deve conter pelo menos 3 caracteres*";
    return false;
  }
  bairroErro.textContent = "";
  return true;
}

function validarLogradouro(logradouro) {
  if (logradouro.trim() === "") {
    logradouroErro.textContent = "Preencha o campo do logradouro*";
    return false;
  }
  if (logradouro.length < 3) {
    logradouroErro.textContent = "O logradouro deve conter pelo menos 3 caracteres*";
    return false;
  }
  logradouroErro.textContent = "";
  return true;
}

function validarNumero(numero) {
  if (numero.trim() === "") {
    numeroErro.textContent = "Preencha o campo do número*";
    return false;
  }
  if (!/^\d+$/.test(numero)) {
    numeroErro.textContent = "O número deve conter apenas dígitos*";
    return false;
  }
  numeroErro.textContent = "";
  return true;
}

function validarComplemento(complemento) {
  // Complemento é opcional, mas caso seja preenchido, deve ter no máximo 50 caracteres
  if (complemento.length > 50) {
    complementoErro.textContent = "O complemento deve ter no máximo 50 caracteres*";
    return false;
  }
  complementoErro.textContent = "";
  return true;
}

function validarSexo() {
  const sexoInput = document.querySelector('input[name="sexo"]:checked');
  if (!sexoInput) {
    alert("Escolha uma opção de sexo*");
    return null;
  }
  return sexoInput.value;
}

// ---------- ENVIO DO FORMULÁRIO ----------

async function enviarFormulario(tipo, email, senha, nome, rg, telefone, dataNascimento, bairro, logradouro, numero, complemento, sexo) {
  const dados = new FormData();
  dados.append("tipo", tipo);
  dados.append("email", email);
  dados.append("senha", senha);
  dados.append("nome", nome);
  dados.append("rg", rg.replace(/\D/g, ''));
  dados.append("telefone", telefone.replace(/\D/g, ''));
  dados.append("dataNascimento", dataNascimento);
  dados.append("bairro", bairro);
  dados.append("logradouro", logradouro);
  dados.append("numero", numero);
  dados.append("complemento", complemento);
  dados.append("sexo", sexo);

  try {
    msgSucesso.innerHTML = "<p style='color:lightblue'>Enviando...</p>";

    const resposta = await fetch("./php/salvarFormCadastro.php", {
      method: "POST",
      body: dados,
    });

    const texto = await resposta.text();
    console.log(texto);

    msgSucesso.innerHTML = "<p style='color:lightgreen'>Cadastro enviado com sucesso!</p>";
  } catch (erro) {
    console.error("Erro ao enviar:", erro);
    msgSucesso.innerHTML = "<p style='color:red'>Erro ao enviar cadastro. Tente novamente.</p>";
  }
}

// ---------- SUBMIT ----------

formulario.addEventListener('submit', function(event) {
  event.preventDefault();

  const tipo = tipoInput.value;
  const email = emailInput.value.trim();
  const senha = senhaInput.value.trim();
  const nome = nomeInput.value.trim();
  const rg = rgInput.value.trim();
  const telefone = telefoneInput.value.trim();
  const data = dataNascimentoInput.value.trim();
  const bairro = bairroInput.value.trim();
  const logradouro = logradouroInput.value.trim();
  const numero = numeroInput.value.trim();
  const complemento = complementoInput.value.trim();
  const sexo = validarSexo();

  const emailValido = validarEmail(email);
  const senhaValida = validarSenha(senha);
  const nomeValido = validarNome(nome);
  const rgValido = validarRG(rg);
  const telefoneValido = validarTelefone(telefone);
  const dataNascimentoValida = validarDataNascimento(data);
  const bairroValido = validarBairro(bairro);
  const logradouroValido = validarLogradouro(logradouro);
  const numeroValido = validarNumero(numero);
  const complementoValido = validarComplemento(complemento);

  if (
    emailValido &&
    senhaValida &&
    nomeValido &&
    rgValido &&
    telefoneValido &&
    dataNascimentoValida &&
    bairroValido &&
    logradouroValido &&
    numeroValido &&
    complementoValido &&
    sexo
  ) {
    enviarFormulario(tipo, email, senha, nome, rg, telefone, data, bairro, logradouro, numero, complemento, sexo);
  } else {
    msgSucesso.innerHTML = "";
  }
});
