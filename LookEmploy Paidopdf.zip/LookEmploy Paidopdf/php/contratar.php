<?php
include_once 'conexaoMySQL.php';
session_start();

$desc = $_POST['descricao'] ?? '';
$dataServico = $_POST['dataServico'] ?? '';
$bairro = $_POST['bairro'] ?? '';
$logradouro = $_POST['logradouro'] ?? '';
$numero = $_POST['numero'] ?? '';
$complemento = $_POST['complemento'] ?? '';
$metodo = $_POST['metodo'] ?? '';
$cliente = $_POST['cliente'];
$prestador = $_POST['prestador'] ?? '';

if (!isset($_SESSION['usuario'])) {
    header('location: login.html');
    exit();
} else {

    // CONVERTER PARA FORMATO MYSQL
    date_default_timezone_set('America/Sao_Paulo');
    $data = date("Y-m-d H:i", strtotime(str_replace('/', '-', $dataServico)));

    $sql_insert = "INSERT INTO servico 
        (bairro, logradouro, numero, complemento, dataServico, tipoPagamento, descricao, contrato, prestador, cliente) 
        VALUES (?, ?, ?, ?, ?, ?, ?, 'pendente', ?, ?)";

    $stmt = $conexao->prepare($sql_insert);

    if (!$stmt) {
        echo "Erro ao preparar o SQL: " . $conexao->error;
        exit;
    }

    $stmt->bind_param(
        'sssssssss',
        $bairro,
        $logradouro,
        $numero,
        $complemento,
        $data,
        $metodo,
        $desc,   // <- corrigido
        $prestador,
        $cliente
    );

    if ($stmt->execute()) {
        echo "EXITO";
        $stmt->close();
        $conexao->close();
    } else {
        echo "Erro ao contratar o serviço: " . $stmt->error;
        exit();
    }
}
?>
