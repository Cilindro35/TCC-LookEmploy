<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Cadastro</title>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" />
  <link rel="stylesheet" href="css/design_cadastro.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
  <link rel="icon" type="image/png" href="img/logo_icon.png" />
  <link href="https://fonts.googleapis.com/css2?family=Anton&display=swap" rel="stylesheet" />
</head>

<body>
  <header>
    <a href="index.html"><img class="headerImg" src="img/logo.png"/></a>
  </header>

  <!-- Conteúdo com fundo -->
   <section class="cadastro">
    <form class="formulario" id="formulario" action="php/salvarFormCadastro.php" method="post">
      <h2>Criar conta</h2>

      <!--Botão de voltar-->
      <div class="row"><a href="index.html"><input type="button" value="Voltar"></a></div>

      <!-- Tipo de conta -->
      <div class="tipoConta">
        <p>Tipo da conta:</p>
        <select class=".select" name="tipo" id="tipo">
          <option value="Cliente">Cliente</option>
          <option value="Prestador">Prestador</option>
        </select>
      </div>

      <input type="email" id="email" name="email" placeholder="Email"/>
      <span id="emailInvalido" style="color: red;"></span>

      <input type="password" id="senha" name="senha" placeholder="Senha" />
      <span id="senhaInvalida" style="color: red;"> </span>

      <input type="text" id="nome" name="nome" placeholder="Nome" />
      <span id="nomeInvalido" style="color: red;"></span>

      <div class="row">
        <input type="text" id="telefone" name="telefone" placeholder="(11) 12345-5678">
        <input type="date" id="dataNascimento" name="dataNascimento" placeholder="Data de Nascimento">
      </div>

      <div class="row">
        <span id="dataNascimentoInvalida" style="color: red;"></span>
        <span id="telefoneInvalido" style="color: red;"></span>
      </div>

      <input type="text" id="bairro" name="bairro" placeholder="Bairro" />
      <span id="bairroInvalido" style="color: red;"></span>

      <input type="text" id="logradouro" name="logradouro" placeholder="Logradouro" />
      <span id="logradouroInvalido" style="color: red;"></span>

      <input type="text" id="numero" name="numero" placeholder="Número" />
      <span id="numeroInvalido" style="color: red;"></span>

      <input type="text" id="complemento" name="complemento" placeholder="Complemento" />
      <span id="complementoInvalido" style="color: red;"></span>

      <div class="row">
        <p id="esco">Sexo:</p>
        <label for="masculino">Masculino</label>
        <input type="radio" id="masculino" name="sexo" value="Masculino" />
        <label for="feminino">Feminino</label>
        <input type="radio" id="feminino" name="sexo" value="Feminino" />
        <label for="prefiroNaoResponder">Prefiro não responder</label>
        <input type="radio" id="prefiroNaoResponder" name="sexo" value="Prefiro não responder" />
      </div>
      <span id="sexoInvalido" style="color: red;"></span>

      <div class="col">
        <p style="text-align: center;">Ao clicar em "Continuar", aceito os <a href="termos-de-uso.html" target="_blank">Termos de Uso</a> 
          e autorizo o uso dos meus dados de acordo com a <a href="declaracao-privacidade.html" target="_blank">Declaração de privacidade</a>.</p> 
          <input type="submit" value="Continuar">
      </div>
      <p id="msgSucesso"></p>
    </form>
    <script src="js/validacaoFormUm.js"></script>
  </section>
</body>
</html>
