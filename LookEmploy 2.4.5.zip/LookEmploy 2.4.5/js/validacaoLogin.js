const formulario = document.getElementById('formulario');

const padraoEmail = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
const padraoLetra = /[a-zA-Z]/;
const padraoNumero = /[0-9]/;

var emailErro = document.getElementById("emailInvalido");
var senhaErro = document.getElementById("senhaInvalida");

// ---------- VALIDAÇÕES ----------

function validarEmail(email) {
  if (email === "") {
   emailErro.textContent = "Preencha o campo do e-mail*";
    return false;
  }
  if (!padraoEmail.test(email)) {
    emailErro.textContent = "E-mail inválido*";
    return false;
  }
  emailErro.textContent = "";
  return true;
}

function validarSenha(senha) {
  if (senha === "") {
    senhaErro.textContent = "Preencha o campo da senha*";
    return false;
  }
  if (senha.length < 6 || !padraoLetra.test(senha) || !padraoNumero.test(senha)) {
    senhaErro.textContent = "A senha deve conter letras, números e ter no mínimo 6 caracteres*";
    return false;
  }
  senhaErro.textContent = "";
  return true;
}

// ---------- SUBMIT ----------

formulario.addEventListener('submit', function(event) {
  event.preventDefault();

  	var tipo = document.getElementById('tipo').value;
  	var email = document.getElementById('email').value.trim();
	  var senha = document.getElementById('senha').value.trim();
	console.log(tipo);
	console.log(email);
	console.log(senha);
 
  	var emailValido = validarEmail(email);
  	var senhaValida = validarSenha(senha);
 
  if (
    emailValido &&
    senhaValida
  ) {
    enviarFormulario(tipo, email, senha);
  } else {
    msgSucesso.innerHTML = "";
  }
});

// ---------- ENVIO DO FORMULÁRIO ----------

async function enviarFormulario(tipo, email, senha) {
  const dados = new FormData();
  dados.append("tipo", tipo);
  dados.append("email", email);
  dados.append("senha", senha);

  try {
    msgSucesso.innerHTML = "<p style='color:lightblue'>Enviando...</p>";

    var resposta = await fetch("./php/salvarFormCadastro.php", {
      method: "POST",
      body: dados,
    });

    var texto = await resposta.text();
    console.log(texto);

    window.location.replace("perfil.html");

  } catch (erro) {
    console.error("Erro ao enviar:", erro);
    msgSucesso.innerHTML = "<p style='color:red'>Erro ao fazer login. Tente novamente.</p>";
  }
}
